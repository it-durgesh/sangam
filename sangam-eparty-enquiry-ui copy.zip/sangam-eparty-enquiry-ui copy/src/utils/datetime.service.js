import dayjs from 'dayjs';
import customParseFormat from 'dayjs/plugin/customParseFormat';
import duration from 'dayjs/plugin/duration';
import toObject from 'dayjs/plugin/toObject';

dayjs.extend(customParseFormat);
dayjs.extend(duration);
dayjs.extend(toObject);

export const formatConversion = (formatString) => {
	/**
	 * Currently we are using dayjs library, conversion map values will come from the library that is being consumed for datetime service.
	 */
	const conversionMap = {
		// date-fns -> dayjs
		yy: 'YY', // Two digit year 01, 02, 19, 23
		yyyy: 'YYYY', // Four digit year 1901, 1903, 2021, 2023
		M: 'M', // Month starting from 1-12 1,2,3,4,5,6,7,8,9,10,11,12
		MM: 'MM', // Month with two digits with 0 appeneded 01, 02, 03, 09, 10, 12
		MMM: 'MMM', // Abbreviated month name Jan, May, Mar, Dec, Apr
		MMMM: 'MMMM', // Full month name January, May, March, April
		d: 'D', // Day starting from 1-31 1, 2, 3, 4, ...29, 30, 31
		dd: 'DD', // Day with two digits with 0 appended 01, 02, 03, 04, ...29, 30, 31
		// do: "Do", // Day of the month with ordinal 1st, 2nd, 3rd, ...29th, 30th, 31st
		H: 'H', // Hours starting from 0-23
		HH: 'HH', // Hours with two digits with 0 appended 01, 02, 03, ...22, 23
		h: 'h', // Hours with 12 hour clock starting from 1-12
		hh: 'hh', // Hours with 12 hour clock with two digits with 0 appended starting from 01-12
		m: 'm', // Minutes starting from 0-59
		mm: 'mm', // Minutes with two digits with 0 appended starting from 00-59
		s: 's', // Seconds starting with 0-59
		ss: 'ss', // Seconds with two digits with 0 appended starting with 00-59
		A: 'A', // 12 hr meridiem all in the capital's AM PM
		a: 'a', // 12 hr meridiem all in the lower case am pm
		S: 'S', // Seconds starting with 0-59
		SS: 'SS', // Seconds with two digits with 0 appended starting with 00-59
		SSS: 'SSS', // Milliseconds with  3-digits having range 000-999
	};

	const unmatchedValue = formatString
		.split(/y+|M+|d+|d+|H+|h+|m+|s+|S+|a+|A+|\W+/g)
		.filter((value) => value !== '');

	if (unmatchedValue.length > 0)
		throw new Error(`Invalid format token : ${unmatchedValue.join(', ')}`);

	const formattedString = formatString.replace(/y+|M+|d+|H+|m+|s+|S+|a+|A+/g, (match) => {
		const matchedvalue = conversionMap[match];
		if (!matchedvalue) throw new Error(`Invalid format token : ${match}`);

		return matchedvalue;
	});
	return formattedString;
};

export const dateToString = (date, format = 'dd-MM-yyyy') => {
	const convertedFormat = formatConversion(format);
	return dayjs(date).format(convertedFormat);
};

export const dateToStringForParseDate = (date, format = 'dd-MM-yyyy') => {
	const convertedFormat = formatConversion(format);
	const convertedDate = dayjs(date);
	const parseDate = dayjs(date, 'DD-MM-YYYY HH:mm:ss.SSSZ');
	return parseDate.isValid()
		? parseDate.format(convertedFormat)
		: convertedDate.format(convertedFormat);
};
