import { gql } from '@apollo/client';

export const GET_QUERY_PARTY_ACCOUNT = gql`
	query findPartyAccountRelationshipView($partyId: String!) {
		findPartyAccountRelationshipView(partyId: $partyId) {
			id
			createdOn
			createdBy
			updatedOn
			updatedBy
			version
			status
			partyId
			accountId
			accountType
			partyRole
		}
	}
`;

export const GET_QUERY_INDIVIDUAL = gql`
	query findPartyPrimaryInformationView($partyId: String!) {
		findPartyPrimaryInformationView(partyId: $partyId) {
			id
			version
			status
			dirty
			deleted
			createdOn
			updatedOn
			createdBy
			updatedBy
			jsonContent {
				... on IndividualPrimaryInformationDTO {
					partyType
					extensionFields
					partyName {
						name {
							prefix
							fullName
						}
						shortName
					}
					familyName {
						fatherName {
							prefix
							fullName
						}
						motherName {
							prefix
							fullName
						}
						spouseName {
							prefix
							fullName
						}
					}
					gender
					maritalStatus
					residentialStatus
					politicalExposure
					birthInformation {
						dateOfBirth
						cityOfBirth
						cityOfBirthLabel
						countryOfBirth
						countryOfBirthLabel
					}
					nationality
					nationalityLabel
					customerSegment
					profitabilityBand
					bankStaff
					prioritySectorCategory
				}
			}
			phoneAddress {
				partyType
				... on IndividualPhoneAddressDTO {
					mobilePhoneNumberDetails {
						id
						countryCode
						phoneNumber
						mobileTypes
					}
					landlinePhoneNumberDetails {
						id
						countryCode
						areaCode
						phoneNumber
						landlineType
					}
				}
			}
			electronicAddress {
				... on IndividualElectronicAddressDTO {
					emailDetails {
						id
						emailId
						emailTypes
					}
				}
			}
			postalAddressDetails {
				... on IndividualPostalAddressDTO {
					postalAddressDetails {
						id
						addressLine1
						addressLine2
						addressLine3
						addressLine4
						city
						cityLabel
						state
						stateLabel
						country
						countryLabel
						pinCode
						addressTypes
						residenceType
					}
				}
			}
			employmentProfile {
				... on IndividualEmploymentProfileDTO {
					partyType
					extensionFields
					annualIncome
					monthlyIncome
					incomeSources
					natureOfBusiness
					occupations {
						... on SalariedOccupationDTO {
							occupationType
							areaOfOccupation
							employerType
							currentEmploymentDetails {
								employerName
								companyCode
								designation
							}
						}
						... on SelfEmployedOccupationDTO {
							occupationType
							areaOfOccupation
							businessType
							companyType
							annualTurnover
						}
						... on ProfessionalOccupationDTO {
							occupationType
							areaOfOccupation
							professionalType
							annualTurnover
						}
						... on OtherOccupationDTO {
							occupationType
							areaOfOccupation
							otherOccupationType
						}
						... on NotEmployedOccupationDTO {
							occupationType
							areaOfOccupation
						}
						... on StudentOccupationDTO {
							occupationType
							areaOfOccupation
						}
						... on HouseWifeOccupationDTO {
							occupationType
							areaOfOccupation
						}
						... on PoliticianOccupationDTO {
							occupationType
							areaOfOccupation
						}
						... on RetiredOccupationDTO {
							occupationType
							areaOfOccupation
						}
					}
				}
			}
			kycProfile {
				... on IndividualKycProfileDTO {
					riskStatus
				}
			}
			riskProfile {
				partyType
				... on IndividualRiskProfileDTO {
					countryOfInitialRisk
					countryOfUltimateRisk
					internalScores {
						scoreName
						score
					}
					externalScores {
						creditBureauName
						bureauScore
						scoreDate
					}
				}
			}
			overseasTaxStatus {
				partyType
				... on IndividualOverseasTaxStatusDTO {
					isOverseasTaxResidencyAvailable
					taxResidenciesDetails {
						countryOfResidence
					}
				}
			}
			taxProfile {
				... on IndividualTaxStatusDTO {
					partyType
					panAvailable
					pan
					form60Or61Available
					panAadhaarLinkages
				}
			}
			partyTag {
				tagDetails {
					tag
					isPartyStatus
				}
			}
			partyStatuses
		}
	}
`;
