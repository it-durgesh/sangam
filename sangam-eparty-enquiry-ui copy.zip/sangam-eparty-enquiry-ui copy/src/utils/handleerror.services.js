import axios from 'axios';

const handleErrorResponse = (error) => {
	let err;
	if (axios.isAxiosError(error)) {
		if (!error.toJSON().status) {
			err = 'Unable to reach server';
		} else {
			err = error.response.data;
		}
	} else {
		err = error.message;
	}
	return err;
};

export default handleErrorResponse;
