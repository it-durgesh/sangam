import { ApolloClient, ApolloLink, concat, createHttpLink, InMemoryCache } from '@apollo/client';
import { ENDPOINT } from '../constants/Routes';

// THIS IS NOT BEING USED ANYWHERE TO BE REMOVED LATER
const host = 'http://localhost';
const port = 3000;
const defaultApiHost = port ? `${host}:${port}` : host;
const url = (process.env.REACT_APP_API_HOST || defaultApiHost).trimRight('/');

const PARTY_INFO_PATH = process.env.REACT_APP_API_PATH_INFO || ENDPOINT.PARTY_INFO;

const PARTY_ACCOUNT_PATH = process.env.REACT_APP_API_PATH_ACCOUNT || ENDPOINT.PARTY_ACCOUNT;

export const PARTY_INFO_ENDPOINT = createHttpLink({
	uri: url + PARTY_INFO_PATH,
});

export const PARTY_ACCOUNT_ENDPOINT = createHttpLink({
	uri: url + PARTY_ACCOUNT_PATH,
});
const authMiddleware = new ApolloLink((operation, forward) => {
	operation.setContext({
		headers: {
			'x-requesting-user': 'party-sync',
			'Cache-Control': 'no-cache',
			'Content-Type': 'application/json',
		},
	});
	return forward(operation);
});

const customApiClient = new ApolloClient({
	link: ApolloLink.split(
		(operation) => operation.getContext().clientName === ENDPOINT.PARTY_INFO,
		concat(authMiddleware, PARTY_INFO_ENDPOINT),
		concat(authMiddleware, PARTY_ACCOUNT_ENDPOINT),
	),
	cache: new InMemoryCache(),
});
export default customApiClient;
