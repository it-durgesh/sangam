/* eslint-disable no-undef */
import { constant } from 'case';

/**
 * Creates an immutable object to hold a constants enum.
 * Variables initializing enums should be in PascalCase.
 * @param {object|string[]} data - values to be create the immutable constant object
 * @returns {object|Proxy} - the immutable object or a Proxy which provides debuggin info
 *                         - values will be transformed to SCREAMING_SNAKE case to represent constants
 * @property {object.getAll} - method added to the enum which will return all values of the enum
 *                           - useful for `oneOf` propType declarations or Array.includes functions
 */
export default function createEnum(data) {
	let newEnum = {};

	if (Array.isArray(data)) {
		data.forEach((datum) => {
			if (typeof datum !== 'string') {
				throw new TypeError('All enum array values must be strings');
			}
			newEnum[constant(datum)] = datum;
		});
	} else if (data !== null && typeof data === 'object') {
		newEnum = Object.entries(data).reduce((formatted, [k, v]) => {
			formatted[constant(k)] = v; // eslint-disable-line no-param-reassign
			return formatted;
		}, {});
	} else {
		throw new TypeError('Data must be an object or an array to create an enum');
	}

	Object.defineProperty(newEnum, 'getAll', {
		value: () => Object.values(newEnum),
	});

	if (process.env.NODE_ENV !== 'production' && window?.Proxy) {
		return new Proxy(newEnum, {
			// trap to provide debugging info for development
			get: (target, name) => {
				if (name === 'getAll') {
					return target.getAll;
				}
				if (!(constant(name) in target)) {
					return undefined;
				}
				return target[constant(name)];
			},

			// trap to prevent addition and/or mutation of object properties
			set: (target, name) => {
				// eslint-disable-next-line no-console
				console.error(`Attempted to set new value for enum key \`${name}\`.`);
				return false;
			},
		});
	}

	return Object.freeze(newEnum);
}
