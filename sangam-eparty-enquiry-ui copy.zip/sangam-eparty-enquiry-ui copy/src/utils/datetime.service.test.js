import dayjs from 'dayjs';
import { formatConversion, dateToString, dateToStringForParseDate } from './datetime.service'; // Replace with actual path

describe('formatConversion', () => {
	it("should convert 'yyyy-MM-dd' to 'YYYY-MM-DD'", () => {
		expect(formatConversion('yyyy-MM-dd')).toBe('YYYY-MM-DD');
	});

	it("should convert 'dd/MM/yyyy' to 'DD/MM/YYYY'", () => {
		expect(formatConversion('dd/MM/yyyy')).toBe('DD/MM/YYYY');
	});

	it('should throw an error for invalid format token', () => {
		expect(() => formatConversion('dd-MM-yyz')).toThrow('Invalid format token : z');
	});

	it("should convert 'hh:mm:ss A' to 'hh:mm:ss A'", () => {
		expect(formatConversion('hh:mm:ss A')).toBe('hh:mm:ss A');
	});

	it("should convert 'HH:mm:ss a' to 'HH:mm:ss a'", () => {
		expect(formatConversion('HH:mm:ss a')).toBe('HH:mm:ss a');
	});
});

describe('dateToString', () => {
	const testDate = new Date(2023, 4, 15, 13, 45, 30); // May 15, 2023, 13:45:30

	it("should format date with default format 'dd-MM-yyyy'", () => {
		expect(dateToString(testDate)).toBe('15-05-2023');
	});

	it("should format date with custom format 'yyyy/MM/dd'", () => {
		expect(dateToString(testDate, 'yyyy/MM/dd')).toBe('2023/05/15');
	});

	it("should format date with custom format 'hh:mm A'", () => {
		expect(dateToString(testDate, 'hh:mm A')).toBe('01:45 PM');
	});

	it("should format date with custom format 'MM-dd-yyyy HH:mm'", () => {
		expect(dateToString(testDate, 'MM-dd-yyyy HH:mm')).toBe('05-15-2023 13:45');
	});
});

describe('dateToStringForParseDate', () => {
	const testDate = new Date(2023, 4, 15, 13, 45, 30); // May 15, 2023, 13:45:30

	it("should format valid date with default format 'dd-MM-yyyy'", () => {
		expect(dateToStringForParseDate(testDate)).toBe('15-05-2023');
	});

	it("should format valid date with custom format 'yyyy/MM/dd'", () => {
		expect(dateToStringForParseDate('2023/05/15', 'yyyy/MM/dd')).toBe('2023/05/15');
	});

	it('should format date if parseDate is invalid', () => {
		expect(dateToStringForParseDate(testDate, 'yyyy/MM/dd')).toBe('2023/05/15');
	});
});
