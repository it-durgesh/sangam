/* eslint-disable no-undef */

/**
 * Generate a compliant and security sensitive random number
 * @returns number
 */
export const getRandom = () => {
	const crypto = window?.crypto || window?.Crypto;
	const array = new Uint32Array(1);
	crypto.getRandomValues(array); // Compliant for security-sensitive use cases
	return array[0];
};

/**
 * Converts an array to a string or
 * returns the original string
 * @param {string[]|string} input array or string
 * @returns {string} The converted string.
 */
export const convertToString = (input) => {
	let result = '';
	if (Array.isArray(input)) {
		result = input.join(', ');
	} else if (typeof input === 'string') {
		result = input;
	}
	return result;
};
