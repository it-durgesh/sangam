import axios from 'axios';

const host = 'http://localhost';
const port = 3000;

const requestHandler = (req) => {
	return req;
};

const defaultApiHost = port ? `${host}:${port}` : host;

const apiHost = (process.env.REACT_APP_API_HOST_IL || defaultApiHost).trimRight('/');

const requestInstance = axios.create({
	headers: {
		Accept: 'application/json',
	},
	mode: 'cors',
	baseURL: `${apiHost}/`,
});

requestInstance.interceptors.request.use((request) => requestHandler(request));

export default requestInstance;
