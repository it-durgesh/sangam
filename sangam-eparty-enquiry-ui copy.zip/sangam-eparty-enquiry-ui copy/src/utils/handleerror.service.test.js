import { handleErrorResponse } from './handleerror.services'; // Replace with the actual file path

describe('handleErrorResponse', () => {
	it("should return 'Unable to reach server' if Axios error has no status", () => {
		const error = {
			isAxiosError: true,
			toJSON: () => ({ status: undefined }),
		};
		const result = handleErrorResponse(error);
		expect(result).toBe('Unable to reach server');
	});

	it('should return the response data if Axios error has status', () => {
		const error = {
			isAxiosError: true,
			toJSON: () => ({ status: 500 }),
			response: {
				data: 'Server error',
			},
		};
		const result = handleErrorResponse(error);
		expect(result).toBe('Server error');
	});

	it("should return the error message if it's not an Axios error", () => {
		const error = new Error('Network error');
		const result = handleErrorResponse(error);
		expect(result).toBe('Network error');
	});
});
