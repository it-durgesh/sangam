import { render } from '@testing-library/react';
import Loader from './Loader';

describe('Loader component ', () => {
	test('calling loader component', async () => {
		render(<Loader className="Sample" accessibleLoaderMessage="Testing" isBlocking={false} />);
	});
});
