import React from 'react';
import { string, bool } from 'prop-types';
import classnames from 'classnames';
import logo from '../../assets/loader.gif';
import './Loader.css';
import makeErrorBoundComponent from '../error-boundary/make-error-bound-component';

const LoaderMessages = Object.freeze({
	PAGE: 'Loading page',
	SECTION: 'Loading section',
});

const Loader = ({ className, accessibleLoaderMessage, isBlocking }) => {
	const classes = classnames('loader', 'hdfc-loader', className, {
		'hdfc-loader--page': isBlocking,
		'hdfc-loader--section': !isBlocking,
	});

	const message =
		!isBlocking && accessibleLoaderMessage === LoaderMessages.PAGE
			? LoaderMessages.SECTION
			: accessibleLoaderMessage;

	return (
		<div className={classes}>
			<div className="hdfc-loader__wrapper">
				<img className="hdfc-loader__loading-bar" src={logo} alt="loading..." />
				<span className="loader__accessible-message">{message}</span>
			</div>
		</div>
	);
};

Loader.displayName = 'Loader';

Loader.propTypes = {
	/** Additional classname for allow BEM naming in a view */
	className: string,
	/** Hidden message describing what is loading for accessibility */
	accessibleLoaderMessage: string,
	/** The page loader blocks the UI */
	isBlocking: bool,
};

Loader.requiredProps = {};

Loader.Messages = LoaderMessages;
export default makeErrorBoundComponent(Loader);
