import { TextField, Typography } from '@mui/material';
import { useController } from 'react-hook-form';
import makeErrorBoundComponent from '../error-boundary/make-error-bound-component';

const TextFieldInput = (props) => {
	const {
		validationRules,
		validationMsg,
		customProps,
		defaultValue,
		'aria-label': ariaLabel,
		control,
		...otherProps
	} = props;
	const nullValPlaceHolder =
		customProps.valueProps && customProps.valueProps.nullPlaceHolder
			? customProps.valueProps.nullPlaceHolder
			: '--';
	const {
		field: { onChange, onBlur, value, ref },
		fieldState: { error },
	} = useController({
		name: props.name,
		control,
		rules: validationRules,
		defaultValue,
	});
	return (
		<>
			{customProps && customProps.readonly ? (
				<>
					<Typography
						variant="body2"
						color="text.secondary"
						{...customProps.labelProps?.typographyProps}
					>
						{props.label}
					</Typography>
					<Typography
						variant="body1"
						color="text.primary"
						{...customProps.valueProps?.typographyProps}
					>
						{value !== ''
							? props.valueFormatter
								? (props.valueFormatter(value) ?? nullValPlaceHolder)
								: value
							: nullValPlaceHolder}
					</Typography>
				</>
			) : (
				<TextField
					{...otherProps}
					InputLabelProps={{ shrink: props.shrink }}
					variant={props.variant}
					name={props.name}
					onChange={(e, ...args) => {
						onChange(e);
						if (props.onChange) props.onChange(e, ...args);
					}}
					onBlur={(e, ...args) => {
						if (props.onBlur) props.onBlur(e, ...args);
						onBlur();
					}}
					onFocus={(e, ...args) => {
						if (props.onFocus) props.onFocus(e, ...args);
					}}
					value={value}
					label={props.label}
					id={props.id}
					error={error !== undefined}
					helperText={
						error
							? validationMsg?.[error.type]
							: props.helperText
								? props.helperText
								: null
					}
					fullWidth={props.fullWidth}
					type={props.type !== undefined ? props.type : 'text'}
					style={{
						width: props.width ? props.width : props.fullWidth ? undefined : 220,
					}}
					disabled={props.disabled}
					inputProps={{
						...props.inputProps,
						...(props.disabled && { 'aria-disabled': true }),
						...(validationRules &&
							validationRules.required &&
							!props.disabled && { 'aria-required': true }),
						...(!props.label && { 'aria-label': ariaLabel }),
					}}
					multiline={props.multiline}
					maxRows={props.maxRows !== undefined ? props.maxRows : ''}
					placeholder={props.placeholder}
					size={props.size ? props.size : 'medium'}
					inputRef={ref}
				/>
			)}
		</>
	);
};

export default makeErrorBoundComponent(TextFieldInput);
