import { render, screen, fireEvent } from '@testing-library/react';
import AnalyticsPage from './AnalyticsPage';

describe('Analytics Page component ', () => {
	test('should print title and count', async () => {
		render(
			<AnalyticsPage title="Analytics" count="3" onClick={() => {}} selectedTitle="Sample" />,
		);

		expect(screen.getByText('Analytics')).toBeInTheDocument();
		expect(screen.getByText('3')).toBeInTheDocument();
	});

	test('should call onClick event by calling onClick call back fn', () => {
		const mockOnClick = jest.fn();

		render(<AnalyticsPage title="Analytics" count="3" selectedTitle="Sample" onClick={mockOnClick} />);
		fireEvent.click(screen.getByRole("heading", {name:'Analytics'}));

		expect(mockOnClick).toHaveBeenCalled();
	});
});
