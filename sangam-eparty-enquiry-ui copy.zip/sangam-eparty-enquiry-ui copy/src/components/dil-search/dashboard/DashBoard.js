import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Box, Button, Container, Grid2, Paper, Typography } from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import VisibilityIcon from '@mui/icons-material/Visibility';
import Fab from '@mui/material/Fab';
import { blue } from '@mui/material/colors';
import {
	fetchBatchStatus,
	fetchByReferenceId,
	resetDilBatchStatus,
} from '../../../views/dil-search/DilBatchStatus.slice';
import { resetBatchSummary } from '../../../views/dil-search/DilBatchSummary.slice';
import TitleVariable from '../../../constants/TitleVariable';
import PATH from '../../../constants/Routes';
import ThunkApiStatus from '../../../constants/ThunkApiStatus';
import makeErrorBoundComponent from '../../error-boundary/make-error-bound-component';
import CustomSnackbar from '../../custom-alert/CustomSnackbar';
import AnalyticsPage from './AnalyticsPage';
import styles from './DashBoard.module.css';

const DashBoard = () => {
	const dispatch = useDispatch();
	const navigate = useNavigate();
	const buttonSx = {
		...{
			bgcolor: blue[500],
			minHeight: '28px',
			width: '28px',
			height: '28px',
			'&:hover': {
				bgcolor: blue[700],
			},
		},
	};

	const [showBatchStatus, setShowBatchStatus] = useState(false);

	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [openInfoSnackbar, setOpenInfoSnackbar] = useState(false);
	const [errorMessage, setErrorMessage] = useState('');

	const [selectedTitle, setSelectedTitle] = useState('');

	const { batchId, businessDate, batchSummaryData } = useSelector(
		(state) => state.DilBatchSummarySlice,
	);
	const { batchStatus, batchStatusData, batchStatusError, referenceIdStatus, referenceIdError } =
		useSelector((state) => state.DilBatchStatusSlice);

	const handleShowBatchStatus = (title) => {
		const param = {
			batchId,
			businessDate,
			status: title,
		};
		dispatch(fetchBatchStatus(param));
		setSelectedTitle(title);
		setShowBatchStatus(true);
	};

	const handleGoBack = () => {
		dispatch(resetBatchSummary());
		dispatch(resetDilBatchStatus());
	};

	const searchByRefId = (referenceId) => {
		const searchByRefIdObj = {
			category: 'reference_id',
			searchValue: referenceId,
			batchId,
			businessDate,
			columnsToFetch: ['status', 'partyId', 'request_payload', 'response_payload'],
		};
		dispatch(fetchByReferenceId(searchByRefIdObj));
	};

	useEffect(() => {
		if (batchStatus === ThunkApiStatus.FAILED) {
			setOpenSnackbar(true);
			setErrorMessage(batchStatusError);
		}
		if (referenceIdStatus === ThunkApiStatus.PENDING) {
			setOpenInfoSnackbar(true);
		}
		if (referenceIdStatus === ThunkApiStatus.FAILED) {
			setOpenSnackbar(true);
			setErrorMessage(referenceIdError);
		}
		if (referenceIdStatus === ThunkApiStatus.SUCCEEDED) {
			navigate(PATH.DIL_SEARCH_DETAIL);
		}
	}, [batchStatus, batchStatusError, referenceIdStatus, referenceIdError, navigate]);

	const isDisableActionButton = referenceIdStatus === ThunkApiStatus.PENDING;

	const columns = [
		{ field: 'ucicId', headerName: `${TitleVariable.UCIC_ID}`, flex: 1 },
		{ field: 'partyId', headerName: `${TitleVariable.PARTY_ID}`, flex: 1 },
		{
			field: 'status',
			headerName: `${TitleVariable.STATUS}`,
			flex: 1,
			disableColumnMenu: true,
		},
		{
			field: 'referenceId',
			headerName: `${TitleVariable.REFERENCE_ID}`,
			flex: 1,
		},
		{
			field: 'action',
			headerName: `${TitleVariable.ACTION}`,
			width: 100,
			disableColumnMenu: true,
			renderCell: ({ row }) => (
				<Fab
					aria-label="save"
					color="primary"
					sx={buttonSx}
					onClick={() => searchByRefId(row.referenceId)}
					disabled={isDisableActionButton}
				>
					<VisibilityIcon sx={{ height: '16px', width: '16px' }} />
				</Fab>
			),
		},
	];

	return (
		<Container maxWidth={false}>
			<Box pt={2} mb={4}>
				<Button
					onClick={handleGoBack}
					sx={{
						padding: '0',
						minWidth: 'initial',
						display: 'flex',
						justifyContent: 'space-between',
					}}
					className={styles.arrowBtn}
				>
					<ArrowBackIcon className={styles.dashBoardBackIcon} />

					{TitleVariable.GO_BACK}
				</Button>
			</Box>

			<Box className={styles.dashBoardBox}>
				<Grid2 container spacing={2}>
					{batchSummaryData?.map((item, index) => {
						return (
							<Grid2 key={index} size={{ xs: 12, md: 4, sm: 6, lg: 3 }}>
								<AnalyticsPage
									onClick={handleShowBatchStatus}
									title={item.status}
									count={item.count}
									selectedTitle={selectedTitle}
								/>
							</Grid2>
						);
					})}
				</Grid2>
			</Box>
			{showBatchStatus && (
				<Paper className={styles.summaryTableMain}>
					<Typography variant="h6" padding={2}>
						{TitleVariable.BATCH_STATUS}
					</Typography>
					<DataGrid
						rows={batchStatusData}
						columns={columns}
						autoHeight
						getRowId={(row) => row.partyId}
						loading={batchStatus === ThunkApiStatus.PENDING}
						initialState={{
							pagination: { paginationModel: { pageSize: 5 } },
						}}
						pageSizeOptions={[5, 10, 25, 50]}
						disableColumnSorting
						disableRowSelectionOnClick
						sx={{
							'.MuiDataGrid-columnHeaderTitle': {
								fontWeight: '600',
							},
						}}
					/>
				</Paper>
			)}
			<CustomSnackbar
				open={openSnackbar}
				message={errorMessage}
				handleOnClose={() => setOpenSnackbar(false)}
			/>
			<CustomSnackbar
				open={openInfoSnackbar}
				message="Please be patient, Fetching Data..."
				handleOnClose={() => setOpenInfoSnackbar(false)}
				type="info"
			/>
		</Container>
	);
};

export default makeErrorBoundComponent(DashBoard);
