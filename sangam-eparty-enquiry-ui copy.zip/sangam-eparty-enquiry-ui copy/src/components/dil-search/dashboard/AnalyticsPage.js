import React, { Card, CardContent, Typography } from '@mui/material';
import classnames from 'classnames';
import makeErrorBoundComponent from '../../error-boundary/make-error-bound-component';
import styles from './DashBoard.module.css';

const AnalyticsPage = (props) => {
	const { title, count, onClick, selectedTitle } = props;

	const className = classnames([styles.cardBox], {
		[styles.cardActive]: selectedTitle === title,
	});

	return (
		<Card className={className} onClick={() => onClick(title)}>
			<CardContent className={styles.dilCardContent}>
				<Typography variant="h6" sx={{ color: '#ffd700', fontWeight: '600' }}>
					{title}
				</Typography>
				<Typography variant="h3" sx={{ color: '#ffd700' }}>
					{count?.toLocaleString()}
				</Typography>
			</CardContent>
		</Card>
	);
};

export default makeErrorBoundComponent(AnalyticsPage);
