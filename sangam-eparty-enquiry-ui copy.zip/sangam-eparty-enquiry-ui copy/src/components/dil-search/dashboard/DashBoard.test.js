import { render, screen, fireEvent } from '@testing-library/react';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import { configureStore } from '@reduxjs/toolkit';
import DashBoard from './DashBoard';
import ThunkApiStatus from '../../../constants/ThunkApiStatus';

const createMockStore = (state) => {
	return configureStore({
		reducer: {
			DilBatchSummarySlice: jest.fn().mockReturnValue(state.DilBatchSummarySlice),
			DilBatchStatusSlice: jest.fn().mockReturnValue(state.DilBatchStatusSlice),
		},
	});
};

describe('DashBoard Component', () => {
	test('renders the DashBoard component', () => {
		const initialState = {
			DilBatchSummarySlice: {
				batchId: 123,
				businessDate: '2024-11-08',
				batchSummaryData: [
					{ status: 'Completed', count: 10 },
					{ status: 'Pending', count: 5 },
				],
			},
			DilBatchStatusSlice: {
				batchStatus: ThunkApiStatus.FAILED,
				batchStatusData: [],
				batchStatusError: '',
				referenceIdStatus: ThunkApiStatus.PENDING,
				referenceIdError: '',
			},
		};
		const store = createMockStore(initialState);
		render(
			<Provider store={store}>
				<BrowserRouter>
					<DashBoard />
				</BrowserRouter>
			</Provider>,
		);

		expect(screen.getByText(/Go Back/i)).toBeInTheDocument();
		expect(screen.getByText(/Completed/i)).toBeInTheDocument();
		expect(screen.getByText(/Pending/i)).toBeInTheDocument();
	});

	test('handles back button click', () => {
		const initialState = {
			DilBatchSummarySlice: {
				batchId: 123,
				businessDate: '2024-11-08',
				batchSummaryData: [
					{ status: 'Completed', count: 10 },
					{ status: 'Pending', count: 5 },
				],
			},
			DilBatchStatusSlice: {
				batchStatus: ThunkApiStatus.SUCCEEDED,
				batchStatusData: [],
				batchStatusError: '',
				referenceIdStatus: ThunkApiStatus.FAILED,
				referenceIdError: '',
			},
		};

		const store = createMockStore(initialState);
		render(
			<Provider store={store}>
				<BrowserRouter>
					<DashBoard />
				</BrowserRouter>
			</Provider>,
		);

		fireEvent.click(screen.getByText(/Go Back/i));
	});

	test('displays loading skeleton when batchStatus is pending', () => {
		const initialState = {
			DilBatchSummarySlice: {
				batchId: 123,
				businessDate: '2024-11-08',
				batchSummaryData: [
					{ status: 'Completed', count: 10 },
					{ status: 'Pending', count: 5 },
				],
			},
			DilBatchStatusSlice: {
				batchStatus: ThunkApiStatus.SUCCEEDED,
				batchStatusData: [],
				batchStatusError: '',
				referenceIdStatus: ThunkApiStatus.SUCCEEDED,
				referenceIdError: '',
			},
		};

		const store = createMockStore(initialState);
		render(
			<Provider store={store}>
				<BrowserRouter>
					<DashBoard />
				</BrowserRouter>
			</Provider>,
		);
	});

	test('displays snackbar when batchStatus fails', async () => {
		const initialState = {
			DilBatchSummarySlice: {
				batchId: 123,
				businessDate: '2024-11-08',
				batchSummaryData: [
					{ status: 'Completed', count: 10 },
					{ status: 'Pending', count: 5 },
				],
			},
			DilBatchStatusSlice: {
				batchStatus: ThunkApiStatus.FAILED,
				batchStatusData: [],
				batchStatusError: '',
				referenceIdStatus: ThunkApiStatus.SUCCEEDED,
				referenceIdError: '',
			},
		};

		const store = createMockStore(initialState);
		render(
			<Provider store={store}>
				<BrowserRouter>
					<DashBoard />
				</BrowserRouter>
			</Provider>,
		);
	});

	test('navigates to the details page when referenceIdStatus is succeeded', async () => {
		const initialState = {
			DilBatchSummarySlice: {
				batchId: 123,
				businessDate: '2024-11-08',
				batchSummaryData: [
					{ status: 'Completed', count: 10 },
					{ status: 'Pending', count: 5 },
				],
			},
			DilBatchStatusSlice: {
				batchStatus: ThunkApiStatus.FAILED,
				batchStatusData: [],
				batchStatusError: '',
				referenceIdStatus: ThunkApiStatus.SUCCEEDED,
				referenceIdError: '',
			},
		};

		const store = createMockStore(initialState);
		render(
			<Provider store={store}>
				<BrowserRouter>
					<DashBoard />
				</BrowserRouter>
			</Provider>,
		);
	});
});
