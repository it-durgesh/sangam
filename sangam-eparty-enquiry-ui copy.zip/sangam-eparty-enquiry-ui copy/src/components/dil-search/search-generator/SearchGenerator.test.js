import { render, screen } from '@testing-library/react';
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import { BrowserRouter } from 'react-router-dom';
import SearchGenerator from './SearchGenerator';

const mockStore = (initialState) => createStore(() => initialState);

jest.mock('../../../constants/TitleVariable', () => ({
	goBack: 'Go Back',
	requestPayload: 'Request Payload',
	responsePayload: 'Response Payload',
}));

jest.mock('../../../constants/Routes', () => ({
	DIL: '/dil',
}));

jest.mock(
	'./RequestPayload',
	() =>
		function () {
			return <div>RequestPayload Component</div>;
		},
);
jest.mock(
	'./ResponsePayload',
	() =>
		function () {
			return <div>ResponsePayload Component</div>;
		},
);

describe('SearchGenerator Component', () => {
	const renderWithProviders = (ui, { initialState }) => {
		const store = mockStore(initialState);
		return render(
			<Provider store={store}>
				<BrowserRouter>{ui}</BrowserRouter>
			</Provider>,
		);
	};

	test('renders go back button and handles click', () => {
		renderWithProviders(<SearchGenerator />, {
			initialState: {
				DilBatchStatusSlice: {
					referenceIdData: [
						{
							status: 'Success',
							request_payload: { value: {} },
							response_payload: { value: {} },
						},
					],
				},
			},
		});
	});

	test('displays RequestPayload and ResponsePayload tabs and switches between them', () => {
		renderWithProviders(<SearchGenerator />, {
			initialState: {
				DilBatchStatusSlice: {
					referenceIdData: [
						{
							status: 'Success',
							request_payload: { value: {} },
							response_payload: { value: {} },
						},
					],
				},
			},
		});

		expect(screen.getByText('RequestPayload Component')).toBeInTheDocument();
		expect(screen.queryByText('ResponsePayload Component')).not.toBeInTheDocument();
	});

	test('does not display tabs if referenceIdData is not present', () => {
		renderWithProviders(<SearchGenerator />, {
			initialState: { DilBatchStatusSlice: { referenceIdData: null } },
		});

		expect(screen.queryByText('Request Payload')).not.toBeInTheDocument();
		expect(screen.queryByText('Response Payload')).not.toBeInTheDocument();
	});

	test('renders tab panels with expected content', () => {
		renderWithProviders(<SearchGenerator />, {
			initialState: {
				DilBatchStatusSlice: {
					referenceIdData: [
						{
							status: 'Success',
							request_payload: { value: {} },
							response_payload: { value: {} },
						},
					],
				},
			},
		});

		expect(screen.getByText('RequestPayload Component')).toBeInTheDocument();
	});
});
