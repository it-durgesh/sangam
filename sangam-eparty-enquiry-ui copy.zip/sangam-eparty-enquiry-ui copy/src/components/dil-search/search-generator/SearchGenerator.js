import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import PropTypes from 'prop-types';
import { Button, Container, Tabs, Tab, Box } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import TitleVariable from '../../../constants/TitleVariable';
import PATH from '../../../constants/Routes';
import { resetDilBatchStatus } from '../../../views/dil-search/DilBatchStatus.slice';
import makeErrorBoundComponent from '../../error-boundary/make-error-bound-component';
import ResponsePayload from './ResponsePayload';
import RequestPayload from './RequestPayload';
import styles from './SearchGenerator.module.css';

const CustomTabPanel = (props) => {
	const { children, value, index, ...other } = props;

	return (
		<div
			role="tabpanel"
			hidden={value !== index}
			id={`generator-tabpanel-${index}`}
			aria-labelledby={`generator-tab-${index}`}
			{...other}
		>
			{value === index && <Box sx={{ p: 3 }}>{children}</Box>}
		</div>
	);
};

CustomTabPanel.propTypes = {
	children: PropTypes.node,
	index: PropTypes.number.isRequired,
	value: PropTypes.number.isRequired,
};

function a11yProps(index) {
	return {
		id: `generator-tab-${index}`,
		'aria-controls': `generator-tabpanel-${index}`,
	};
}

const SearchGenerator = () => {
	const navigate = useNavigate();
	const dispatch = useDispatch();

	const { referenceIdData } = useSelector((state) => state.DilBatchStatusSlice);
	const status = (referenceIdData && referenceIdData[0].status) || '';
	const requestPayload = (referenceIdData && referenceIdData[0].request_payload.value) || {};
	const responsePayload = (referenceIdData && referenceIdData[0].response_payload.value) || {};

	const handleGoBack = () => {
		dispatch(resetDilBatchStatus());
		navigate(PATH.DIL);
	};

	const [value, setValue] = React.useState(0);

	const handleChange = (event, newValue) => {
		setValue(newValue);
	};

	return (
		<Container maxWidth={false}>
			<Box pt={2} mb={4}>
				<Button
					onClick={handleGoBack}
					sx={{
						padding: '0',
						minWidth: 'initial',
						display: 'flex',
						justifyContent: 'space-between',
					}}
					className={styles.arrowBtn}
				>
					<ArrowBackIcon className={styles.dashBoardBackIcon} />

					{TitleVariable.GO_BACK}
				</Button>
			</Box>
			<Box sx={{ width: '100%', backgroundColor: '#fff' }}>
				{referenceIdData && (
					<>
						<Box sx={{ borderBottom: 1, bgcolor: 'background.paper' }}>
							<Tabs
								value={value}
								onChange={handleChange}
								textColor="primary"
								indicatorColor="primary"
								aria-label="reference-id-payload"
								centered
								variant="fullWidth"
							>
								<Tab label={TitleVariable.REQUEST_PAYLOAD} {...a11yProps(0)} />
								<Tab label={TitleVariable.RESPONSE_PAYLOAD} {...a11yProps(1)} />
							</Tabs>
						</Box>
						<CustomTabPanel value={value} index={0}>
							<RequestPayload status={status} requestPayload={requestPayload} />
						</CustomTabPanel>
						<CustomTabPanel value={value} index={1}>
							<ResponsePayload status={status} responsePayload={responsePayload} />
						</CustomTabPanel>
					</>
				)}
			</Box>
		</Container>
	);
};

export default makeErrorBoundComponent(SearchGenerator);
