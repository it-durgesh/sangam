import { render } from '@testing-library/react';
import ResponsePayload from './ResponsePayload';

describe('Response Payload component ', () => {
	test('calling response payload component', async () => {
		render(<ResponsePayload status="success" responsePayload='{"header":{}, "body":{}}' />);
	});
});
