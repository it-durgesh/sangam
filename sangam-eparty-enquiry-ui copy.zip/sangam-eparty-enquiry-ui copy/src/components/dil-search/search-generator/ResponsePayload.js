import React from 'react';
import { JsonView, allExpanded, defaultStyles } from 'react-json-view-lite';
import { Paper, Box, Typography, Chip, Tooltip } from '@mui/material';
import TitleVariable from '../../../constants/TitleVariable';
import makeErrorBoundComponent from '../../error-boundary/make-error-bound-component';
import 'react-json-view-lite/dist/index.css';
import styles from './SearchGenerator.module.css';

const ResponsePayload = (props) => {
	const { status, responsePayload } = props;
	const content = JSON.parse(responsePayload) || {};
	return (
		<>
			<Box className={styles.statusText}>
				<Typography mr={1}>{TitleVariable.RESPONSE_PAYLOAD}</Typography>
				<Tooltip title={TitleVariable.STATUS} arrow placement="top">
					<Chip label={status} color="info" sx={{ cursor: 'pointer' }} />
				</Tooltip>
			</Box>
			<Paper className={styles.tabContentBox} elevation={3}>
				<Typography mb={2}>{TitleVariable.VALUE}</Typography>
				<JsonView shouldExpandNode={allExpanded} style={defaultStyles} data={content} />
			</Paper>
		</>
	);
};

export default makeErrorBoundComponent(ResponsePayload);
