import { render } from '@testing-library/react';
import RequestPayload from './RequestPayload';

describe('Request Payload component ', () => {
	test('calling request payload component', async () => {
		render(<RequestPayload status="success" requestPayload='{"header":{}, "body":{}}' />);
	});
});
