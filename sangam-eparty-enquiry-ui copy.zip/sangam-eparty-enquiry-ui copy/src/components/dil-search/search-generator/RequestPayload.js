import React from 'react';
import { JsonView, allExpanded, defaultStyles } from 'react-json-view-lite';
import { Chip, Paper, Typography, Box, Tooltip } from '@mui/material';
import TitleVariable from '../../../constants/TitleVariable';
import makeErrorBoundComponent from '../../error-boundary/make-error-bound-component';
import 'react-json-view-lite/dist/index.css';
import styles from './SearchGenerator.module.css';

const RequestPayload = (props) => {
	const { status, requestPayload } = props;
	const content = JSON.parse(requestPayload);
	const header = content?.header || {};
	const body = content?.body || {};
	return (
		<>
			<Box className={styles.statusText}>
				<Typography mr={1}>{TitleVariable.REQUEST_PAYLOAD}</Typography>
				<Tooltip title={TitleVariable.STATUS} arrow placement="top">
					<Chip label={status} color="info" sx={{ cursor: 'pointer' }} />
				</Tooltip>
			</Box>

			<Paper className={styles.tabContentBox} elevation={3}>
				<Typography mb={2}>{TitleVariable.REQUEST_HEADER}</Typography>
				<JsonView shouldExpandNode={allExpanded} style={defaultStyles} data={header} />
			</Paper>
			<Paper className={styles.tabContentBox} elevation={3}>
				<Typography mb={2}>{TitleVariable.REQUEST_BODY}</Typography>
				<JsonView shouldExpandNode={allExpanded} style={defaultStyles} data={body} />
			</Paper>
		</>
	);
};

export default makeErrorBoundComponent(RequestPayload);
