import { render, screen, fireEvent } from '@testing-library/react';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import SearchForm from './SearchForm';
import ThunkApiStatus from '../../../constants/ThunkApiStatus';

const mockStore = configureStore([]);

describe('SearchForm Component', () => {
	let store;

	beforeEach(() => {
		store = mockStore({
			DilBatchSummarySlice: {
				batchSummaryStatus: ThunkApiStatus.IDLE,
				batchSummaryError: '',
			},
			DilBatchStatusSlice: {
				referenceIdStatus: ThunkApiStatus.SUCCEEDED,
				referenceIdError: '',
			},
		});
	});

	const renderComponent = () =>
		render(
			<Provider store={store}>
				<BrowserRouter>
					<SearchForm />
				</BrowserRouter>
			</Provider>,
		);

	it('should render form fields and submit button', () => {
		renderComponent();
		expect(screen.getByLabelText(/batch id/i)).toBeInTheDocument();
		expect(screen.getByLabelText(/business date/i)).toBeInTheDocument();
		expect(screen.getByRole('button', { name: /search/i })).toBeInTheDocument();
	});

	it('should toggle referenceId input on checkbox click', () => {
		renderComponent();
		const checkbox = screen.getByLabelText(/check for search by reference id/i);
		fireEvent.click(checkbox);
	});

	it('should show loading indicator when isLoading is true', () => {
		store = mockStore({
			DilBatchSummarySlice: {
				batchSummaryStatus: ThunkApiStatus.PENDING,
				batchSummaryError: '',
			},
			DilBatchStatusSlice: { referenceIdStatus: ThunkApiStatus.IDLE, referenceIdError: '' },
		});
		renderComponent();
		expect(screen.getByRole('button', { name: /search/i })).toBeDisabled();
		expect(screen.getByRole('progressbar')).toBeInTheDocument();
	});

	it('should show error message in snackbar when batchSummaryStatus is failed', async () => {
		store = mockStore({
			DilBatchSummarySlice: {
				batchSummaryStatus: ThunkApiStatus.FAILED,
				batchSummaryError: 'Batch Summary Error',
			},
			DilBatchStatusSlice: { referenceIdStatus: ThunkApiStatus.IDLE, referenceIdError: '' },
		});
		renderComponent();
		expect(await screen.findByText(/batch summary error/i)).toBeInTheDocument();
	});

	it('should dispatch fetchBatchSummary on form submit when referenceId checkbox is unchecked', async () => {
		renderComponent();
		fireEvent.change(screen.getByLabelText(/batch id/i), { target: { value: '12345' } });
		fireEvent.change(screen.getByLabelText(/business date/i), {
			target: { value: '2023-01-01' },
		});
		fireEvent.click(screen.getByRole('button', { name: /search/i }));
	});

	it('should navigate to detail page on successful referenceIdStatus', async () => {
		store = mockStore({
			DilBatchSummarySlice: {
				batchSummaryStatus: ThunkApiStatus.IDLE,
				batchSummaryError: '',
			},
			DilBatchStatusSlice: { referenceIdStatus: ThunkApiStatus.FAILED, referenceIdError: '' },
		});

		renderComponent();
	});

	it('should dispatch fetchByReferenceId on form submit when referenceId checkbox is checked', async () => {
		renderComponent();
		const checkbox = screen.getByLabelText(/check for search by reference id/i);
		fireEvent.click(checkbox);
		fireEvent.change(screen.getByLabelText(/batch id/i), { target: { value: '12345' } });
		fireEvent.change(screen.getByLabelText(/business date/i), {
			target: { value: '2023-01-01' },
		});
		fireEvent.click(screen.getByRole('button', { name: /search/i }));
	});
});
