import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import {
	Box,
	Button,
	Paper,
	Container,
	Stack,
	Checkbox,
	FormGroup,
	FormControlLabel,
	Typography,
} from '@mui/material';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import Grid from '@mui/material/Grid2';
import CircularProgress from '@mui/material/CircularProgress';
import PATH from '../../../constants/Routes';
import {
	fetchByReferenceId,
	resetDilBatchStatus,
} from '../../../views/dil-search/DilBatchStatus.slice';
import { fetchBatchSummary } from '../../../views/dil-search/DilBatchSummary.slice';
import TitleVariable from '../../../constants/TitleVariable';
import ValidationMessages from '../../../constants/ValidationMessage';
import ThunkApiStatus from '../../../constants/ThunkApiStatus';
import { dateToString } from '../../../utils/datetime.service';
import TextFieldInput from '../../text-field-input/TextFieldInput';
import makeErrorBoundComponent from '../../error-boundary/make-error-bound-component';
import CustomSnackbar from '../../custom-alert/CustomSnackbar';
import DatePickerInput from '../../date-picker/DatePickerInput';
import styles from './SearchForm.module.css';

const SearchForm = () => {
	const dispatch = useDispatch();
	const navigate = useNavigate();

	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [errorMessage, setErrorMessage] = useState('');
	const [selectReferenceId, setSelectReferenceId] = useState(false);

	const { batchSummaryStatus, batchSummaryError } = useSelector(
		(state) => state.DilBatchSummarySlice,
	);

	const { referenceIdStatus, referenceIdError } = useSelector(
		(state) => state.DilBatchStatusSlice,
	);

	const { handleSubmit, control, watch } = useForm({
		defaultValues: {
			batchId: '',
			businessDate: null,
		},
	});

	const validationRules = {
		batchId: {
			required: true,
		},
		businessDate: {
			required: true,
		},
		referenceId: {
			required: true,
		},
	};
	const validationMessage = {
		batchId: {
			required: `${ValidationMessages.BATCH_ID}`,
		},
		businessDate: {
			required: `${ValidationMessages.BUSINESS_DATE}`,
		},
		referenceId: {
			required: `${ValidationMessages.REFERENCE_ID}`,
		},
	};

	const onSubmit = () => {
		dispatch(resetDilBatchStatus());
		const batchId = watch('batchId');
		const selectedDate = watch('businessDate');
		const dateString = dateToString(selectedDate);
		if (selectReferenceId) {
			const referenceId = watch('referenceId');
			const searchByRefIdObj = {
				category: 'reference_id',
				searchValue: referenceId,
				batchId,
				businessDate: dateString,
				columnsToFetch: ['status', 'partyId', 'request_payload', 'response_payload'],
			};
			dispatch(fetchByReferenceId(searchByRefIdObj));
		} else {
			const searchObj = {
				batchId,
				businessDate: dateString,
			};
			dispatch(fetchBatchSummary(searchObj));
		}
	};

	const handleChange = () => {
		setSelectReferenceId(!selectReferenceId);
	};

	const isLoading = batchSummaryStatus === ThunkApiStatus.PENDING;

	useEffect(() => {
		if (batchSummaryStatus === ThunkApiStatus.FAILED) {
			setOpenSnackbar(true);
			setErrorMessage(batchSummaryError);
		}
	}, [batchSummaryStatus, batchSummaryError]);

	useEffect(() => {
		if (referenceIdStatus === ThunkApiStatus.FAILED) {
			setOpenSnackbar(true);
			setErrorMessage(referenceIdError);
		}
		if (referenceIdStatus === ThunkApiStatus.SUCCEEDED) {
			navigate(PATH.DIL_SEARCH_DETAIL);
		}
	}, [referenceIdStatus, referenceIdError, navigate]);

	return (
		<Container>
			<form onSubmit={handleSubmit(onSubmit)}>
				<Box mt={3}>
					<Paper className={styles.outerPaperForm}>
						<FormGroup sx={{ display: 'inline-flex' }}>
							<FormControlLabel
								control={
									<Checkbox
										inputProps={{
											'aria-label': 'Check for search by reference Id',
										}}
									/>
								}
								label={
									<Typography variant="body1">
										{TitleVariable.SEARCH_BY_REF_ID}
									</Typography>
								}
								onChange={handleChange}
							/>
						</FormGroup>
						<Grid container spacing={3} mt={2}>
							<Grid size={{ xs: 12, md: 6 }}>
								<LocalizationProvider dateAdapter={AdapterDayjs}>
									<DatePickerInput
										label={TitleVariable.BUSINESS_DATE}
										name="businessDate"
										control={control}
										customProps={{ readonly: false }}
										fullWidth
										size="small"
										validationRules={validationRules.businessDate}
										validationMsg={validationMessage.businessDate}
									/>
								</LocalizationProvider>
							</Grid>
							<Grid size={{ xs: 12, md: 6 }}>
								<TextFieldInput
									control={control}
									name="batchId"
									label="Batch Id"
									customProps={{ readonly: false }}
									fullWidth
									size="small"
									validationRules={validationRules.batchId}
									validationMsg={validationMessage.batchId}
								/>
							</Grid>
							{selectReferenceId && (
								<Grid size={{ xs: 12, md: 6 }}>
									<TextFieldInput
										control={control}
										name="referenceId"
										label="Reference Id"
										customProps={{ readonly: false }}
										fullWidth
										size="small"
										validationRules={validationRules.referenceId}
										validationMsg={validationMessage.referenceId}
									/>
								</Grid>
							)}
						</Grid>
						<Stack direction="row" justifyContent="right" m={2}>
							<Button
								disabled={isLoading}
								variant="contained"
								type="submit"
								size="large"
							>
								{TitleVariable.SEARCH}
								{isLoading && (
									<CircularProgress
										color="inherit"
										sx={{ marginLeft: '0.625rem' }}
										size="1.5rem"
									/>
								)}
							</Button>
						</Stack>
					</Paper>
				</Box>
			</form>
			<CustomSnackbar
				open={openSnackbar}
				message={errorMessage}
				handleOnClose={() => setOpenSnackbar(false)}
			/>
		</Container>
	);
};
export default makeErrorBoundComponent(SearchForm);
