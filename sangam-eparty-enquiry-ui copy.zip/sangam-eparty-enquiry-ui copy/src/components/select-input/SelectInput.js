import {
	FormControl,
	FormHelperText,
	InputLabel,
	ListItemIcon,
	ListItemText,
	MenuItem,
	Select,
	Stack,
	Typography,
} from '@mui/material';
import { useController } from 'react-hook-form';
import { getRandom } from '../../utils/commonutil.service';
import './SelectInput.css';
import styles from './SelectInput.module.css';

const SelectInput = (props) => {
	const {
		validationRules,
		validationMsg,
		customProps,
		selectOptions,
		defaultValue,
		'aria-label': ariaLabel,
		control,
		id,
		enabledMenuItems,
		disabledMenuItems,
		...otherProps
	} = props;

	const nullValPlaceHolder =
		customProps.valueProps && customProps.valueProps.nullPlaceHolder
			? customProps.valueProps.nullPlaceHolder
			: '--';

	const shouldDisable = (value) => {
		if (disabledMenuItems && selectOptions) {
			if (disabledMenuItems.includes(value)) return true;
			return false;
		}
		if (enabledMenuItems && selectOptions) {
			if (!enabledMenuItems.includes(value)) return true;
			return false;
		}
		return false;
	};

	const generatedSelectOptions = () => {
		return selectOptions.map((option) => {
			const disableOption = shouldDisable(option.value);
			return props.iconprop ? (
				<MenuItem
					key={option.value}
					value={option.value}
					disabled={option.disabled || disableOption}
					className={styles.menuItems}
				>
					{props?.iconprop?.[option.value] && (
						<Stack direction="row" alignItems="center">
							<ListItemIcon className={styles.icon}>
								{props?.iconprop?.[option.value]}
							</ListItemIcon>
							<ListItemText className={styles.lovText}>{option.label}</ListItemText>
						</Stack>
					)}
					{!props?.iconprop?.[option.value] && props?.iconprop?.default && (
						<Stack direction="row" alignItems="center">
							<ListItemIcon className={styles.icon}>
								{props?.iconprop?.default}
							</ListItemIcon>
							<ListItemText className={styles.lovText}>{option.label}</ListItemText>
						</Stack>
					)}
				</MenuItem>
			) : (
				<MenuItem
					key={option.value}
					value={option.value}
					disabled={option.disabled || disableOption}
				>
					{option.label}
				</MenuItem>
			);
		});
	};

	const {
		field: { onChange, onBlur, value, ref },
		fieldState: { error },
	} = useController({
		name: props.name,
		control,
		rules: validationRules,
		defaultValue,
	});
	const random = Math.floor(getRandom() * 1000);
	return (
		<>
			{customProps && customProps.readonly ? (
				<>
					<Typography
						variant="body2"
						color="text.secondary"
						{...customProps.labelProps?.typographyProps}
					>
						{props.label}
					</Typography>
					<Typography
						variant="body1"
						color="text.primary"
						className={styles.valueTypographyStyle}
						{...customProps.valueProps?.typographyProps}
					>
						{props.multiple
							? value && value.length > 0
								? value
										.map((item) =>
											selectOptions
												.filter((obj) => obj.value === item)
												.map((obj) => obj.label),
										)
										.join(', ')
								: nullValPlaceHolder
							: value !== ''
								? selectOptions.find((obj) => obj.value === value)?.label
								: nullValPlaceHolder}
					</Typography>
				</>
			) : (
				<FormControl
					style={{
						width: props.width ? props.width : props.fullWidth ? '' : 220,
					}}
					fullWidth={props.fullWidth}
					variant={props.variant}
				>
					{props.label && (
						<InputLabel
							error={error !== undefined}
							id={`${random}_${props.name?.replace(/\s/g, '')}`}
							size={props.size ? props.size : 'normal'}
						>
							{props.label}
						</InputLabel>
					)}

					<Select
						{...otherProps}
						inputProps={{
							...otherProps.inputProps,
							...(validationRules &&
								validationRules.required &&
								!props.disabled && { 'aria-required': true }),
							...(props.disabled && { 'aria-disabled': true }),
						}}
						slotProps={{
							...otherProps.slotProps,
							input: {
								...otherProps.slotProps?.input,
								...(props.id && { 'aria-labelledby': `${id}_${id}`, id }),
							},
							root: {
								...otherProps.slotProps?.root,
								...(props.id &&
									!props.label && {
										'aria-label': ariaLabel,
										id: `${random}_${props.name?.replace(/\s/g, '')}`,
									}),
							},
						}}
						id={`${id}_${id}`}
						error={error !== undefined}
						labelId={`${random}_${props.name?.replace(/\s/g, '')}`}
						label={props.label}
						onChange={(e, ...args) => {
							if (props.onChange) props.onChange(e, ...args);
							onChange(e);
						}}
						onBlur={(e, ...args) => {
							if (props.onBlur) props.onBlur(e, ...args);
							onBlur();
						}}
						onFocus={(e, ...args) => {
							if (props.onFocus) props.onFocus(e, ...args);
						}}
						value={value}
						multiple={props.multiple}
						disabled={props.disabled}
						size={props.size ? props.size : 'medium'}
						inputRef={ref}
						defaultValue={props.defaultValue}
						// disabledMenuItems = {}
					>
						{generatedSelectOptions()}
					</Select>
					<FormHelperText error={error !== undefined}>
						{error ? validationMsg?.[error.type] : null}
					</FormHelperText>
				</FormControl>
			)}
		</>
	);
};
export function main() {
	const byteArray = new Uint8Array(1);
	return window.crypto.getRandomValues(byteArray);
}

export default SelectInput;
