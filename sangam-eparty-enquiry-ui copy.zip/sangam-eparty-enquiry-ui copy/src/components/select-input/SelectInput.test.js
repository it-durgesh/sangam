import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { useForm } from 'react-hook-form';
import SelectInput, { main } from './SelectInput';

const customProps = { valueProps: { nullPlaceHolder: 'No value selected' } };

const setup = (props) => {
	const Wrapper = () => {
		const { control } = useForm();
		return <SelectInput control={control} {...props} customProps={customProps} />;
	};
	return render(<Wrapper />);
};

describe('SelectInput Component', () => {
	const selectOptions = [
		{ value: '1', label: 'Option 1' },
		{ value: '2', label: 'Option 2' },
		{ value: '3', label: 'Option 3', disabled: true },
	];

	it('should pass', () => {
		const mGetRandomValues = jest.fn().mockReturnValueOnce(new Uint32Array(10));
		Object.defineProperty(window, 'crypto', {
			value: { getRandomValues: mGetRandomValues },
		});
		expect(main()).toEqual(new Uint32Array(10));
		expect(mGetRandomValues).toBeCalledWith(new Uint8Array(1));
	});

	test('renders SelectInput with label', () => {
		setup({
			name: 'testSelect',
			label: 'Test Label',
			selectOptions,
		});
		expect(screen.getByLabelText('Test Label')).toBeInTheDocument();
	});

	test('displays correct options', () => {
		setup({
			name: 'testSelect',
			label: 'Test Label',
			selectOptions,
		});
		fireEvent.mouseDown(screen.getByLabelText('Test Label'));
		selectOptions.forEach((option) => {
			expect(screen.getByText(option.label)).toBeInTheDocument();
		});
	});

	test('handles disabled options correctly', () => {
		setup({
			name: 'testSelect',
			label: 'Test Label',
			selectOptions,
		});
		fireEvent.mouseDown(screen.getByLabelText('Test Label'));
		const disabledOption = screen.getByText('Option 3');
		expect(disabledOption).toHaveAttribute('aria-disabled', 'true');
	});

	test('calls onChange when an option is selected', () => {
		const onChangeMock = jest.fn();
		setup({
			name: 'testSelect',
			label: 'Test Label',
			selectOptions,
			onChange: onChangeMock,
		});
		fireEvent.mouseDown(screen.getByLabelText('Test Label'));
		fireEvent.click(screen.getByText('Option 1'));
		expect(onChangeMock).toHaveBeenCalled();
	});

	test('renders custom placeholder if no selection', () => {
		setup({
			name: 'testSelect',
			label: 'Test Label',
			selectOptions,
			customProps: { valueProps: { nullPlaceHolder: 'Select an option' } },
		});
	});
});
