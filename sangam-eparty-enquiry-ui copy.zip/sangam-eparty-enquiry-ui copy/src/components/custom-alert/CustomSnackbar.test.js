import { render } from '@testing-library/react';
import CustomSnackbar from './CustomSnackbar';

describe('CustomSnackbar component ', () => {
	test('calling custom snackbar component', async () => {
		render(<CustomSnackbar open message="hello" handleOnClose />);
	});
});
