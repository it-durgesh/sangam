import React, { Alert, Snackbar, Typography } from '@mui/material';

const CustomSnackbar = ({
	open,
	message,
	handleOnClose,
	vertical = 'top',
	horizontal = 'center',
	type = 'error',
}) => {
	return (
		<Snackbar
			open={open}
			autoHideDuration={5000}
			anchorOrigin={{ vertical, horizontal }}
			key={vertical + horizontal}
			onClose={handleOnClose}
		>
			<Alert severity={type}>
				<Typography>{message}</Typography>
			</Alert>
		</Snackbar>
	);
};

export default CustomSnackbar;
