import { render, screen, fireEvent } from '@testing-library/react';
import { Provider, useDispatch } from 'react-redux';
import configureStore from 'redux-mock-store';
import SearchForm from './SearchForm';
import { resetUcicIdSearch } from '../../../views/eparty-search/UcicIdSearch.slice';

// Mock dependencies
jest.mock('react-redux', () => ({
	...jest.requireActual('react-redux'),
	useDispatch: jest.fn(),
}));

const mockStore = configureStore([]);

describe('SearchForm Component', () => {
	let store;
	let dispatchMock;

	beforeEach(() => {
		store = mockStore({
			UcicIdSearchSlice: {
				ucicIdSearchData: null,
			},
		});

		dispatchMock = jest.fn();
		useDispatch.mockReturnValue(dispatchMock);
	});

	afterEach(() => {
		jest.clearAllMocks();
	});

	test('renders SearchForm with initial state', () => {
		render(
			<Provider store={store}>
				<SearchForm />
			</Provider>,
		);

		expect(screen.getByText(/Party ID/i)).toBeInTheDocument();
		expect(screen.getByText(/UCIC ID/i)).toBeInTheDocument();
	});

	test('changes selected value when Party ID button is clicked', () => {
		render(
			<Provider store={store}>
				<SearchForm />
			</Provider>,
		);

		const partyIdButton = screen.getByText(/Party ID/i).closest('button');
		fireEvent.click(partyIdButton);

		expect(dispatchMock).toHaveBeenCalledWith(resetUcicIdSearch());
		expect(screen.getByRole('radio', { checked: true })).toBeInTheDocument();
	});

	test('changes selected value when UCIC ID button is clicked', () => {
		render(
			<Provider store={store}>
				<SearchForm />
			</Provider>,
		);

		const ucicIdButton = screen.getByText(/UCIC ID/i).closest('button');
		fireEvent.click(ucicIdButton);
	});

	test('renders UcicidTable component when ucicIdSearchData is present', () => {
		store = mockStore({
			UcicIdSearchSlice: {
				ucicIdSearchData: {
					/* mock data */
				},
			},
		});
	});
});
