import { render } from '@testing-library/react';
import { Provider } from 'react-redux';
import { MockedProvider } from '@apollo/client/testing';
import configureStore from 'redux-mock-store';
import { useNavigate } from 'react-router-dom';
import PartyIdForm from './PartyIdForm';
import { GET_QUERY_INDIVIDUAL } from '../../../../utils/epartygqlsearch.service';

const mockStore = configureStore([]);

// Mock the useNavigate hook
jest.mock('react-router-dom', () => ({
	...jest.requireActual('react-router-dom'),
	useNavigate: jest.fn(),
}));

describe('PartyIdForm Component', () => {
	let store;
	const mockNavigate = jest.fn();

	beforeEach(() => {
		store = mockStore({
			EpartySearchSlice: {
				searchStatus: 'IDLE',
			},
		});
		store.dispatch = jest.fn();
		useNavigate.mockReturnValue(mockNavigate);
	});

	const renderComponent = (mocks = []) =>
		render(
			<Provider store={store}>
				<MockedProvider mocks={mocks} addTypename={false}>
					<PartyIdForm />
				</MockedProvider>
			</Provider>,
		);

	const mocks = [
		{
			request: {
				query: GET_QUERY_INDIVIDUAL,
				variables: { partyId: '12345' },
				context: { clientName: 'PARTY_INFO' },
			},
			result: {
				data: { getIndividualData: { partyId: '12345' } },
			},
		},
	];

	it('renders form components', () => {
		renderComponent();
	});
});
