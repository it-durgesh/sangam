import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { useLazyQuery } from '@apollo/client';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import Grid from '@mui/material/Grid2';
import CircularProgress from '@mui/material/CircularProgress';
import { setData, setError, setLoading } from '../../../../views/eparty-search/EpartySearch.slice';
import PATH, { ENDPOINT } from '../../../../constants/Routes';
import { GET_QUERY_INDIVIDUAL } from '../../../../utils/epartygqlsearch.service';
import ThunkApiStatus from '../../../../constants/ThunkApiStatus';
import makeErrorBoundComponent from '../../../error-boundary/make-error-bound-component';
import SelectInput from '../../../select-input/SelectInput';
import TextFieldInput from '../../../text-field-input/TextFieldInput';
import CustomSnackbar from '../../../custom-alert/CustomSnackbar';
import TitleVariable from '../../../../constants/TitleVariable';
import ValidationMessages from '../../../../constants/ValidationMessage';
import { PARTY_TYPE } from '../../../../constants/Common';

const PartyIdForm = () => {
	const dispatch = useDispatch();
	const navigate = useNavigate();

	const [fetchIData, { loading: iLoading, error: iError, data: iData }] =
		useLazyQuery(GET_QUERY_INDIVIDUAL);

	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [errorMessage, setErrorMessage] = useState('');

	const { searchStatus } = useSelector((state) => state.EpartySearchSlice);

	const PARTY_TYPE_OPTION = [
		{ label: PARTY_TYPE.INDIVIDUAL, value: PARTY_TYPE.INDIVIDUAL },
		{
			label: PARTY_TYPE.NON_INDIVIDUAL,
			value: Object.keys(PARTY_TYPE)[1],
		},
	];
	const { handleSubmit, control, watch } = useForm({
		defaultValues: {
			partyId: '',
			partyType: PARTY_TYPE.INDIVIDUAL,
		},
	});

	const validationRules = {
		partyType: {
			required: true,
		},
		partyId: {
			required: true,
		},
	};
	const validationMessage = {
		partyType: {
			required: `${ValidationMessages.PARTY_TYPE}`,
		},
		partyId: {
			required: `${ValidationMessages.PARTY_ID}`,
		},
	};

	useEffect(() => {
		if (iLoading) {
			dispatch(setLoading());
		} else if (iData) {
			dispatch(setData(iData));
			navigate(PATH.EPARTY_DETAIL);
		} else if (iError) {
			dispatch(setError(iError?.message));
			setOpenSnackbar(true);
			setErrorMessage(iError?.message);
		}
	}, [iLoading, iError, iData, dispatch, navigate]);

	const onSubmit = () => {
		const partyId = watch('partyId');
		const variables = {
			partyId,
		};
		fetchIData({ variables, context: { clientName: ENDPOINT.PARTY_INFO } });
	};

	const isLoading = searchStatus === ThunkApiStatus.PENDING;

	return (
		<>
			<form onSubmit={handleSubmit(onSubmit)}>
				<Box>
					<Grid container spacing={4}>
						<Grid size={{ xs: 12, md: 6 }}>
							<SelectInput
								fullWidth
								label="Party Type"
								name="partyType"
								control={control}
								customProps={{ readonly: false }}
								selectOptions={PARTY_TYPE_OPTION}
								id="party-type"
								size="small"
								disabled
								validationRules={validationRules.partyType}
								validationMsg={validationMessage.partyType}
							/>
						</Grid>
						<Grid size={{ xs: 12, md: 6 }}>
							<TextFieldInput
								control={control}
								name="partyId"
								label="Party Id"
								customProps={{ readonly: false }}
								fullWidth
								size="small"
								validationRules={validationRules.partyId}
								validationMsg={validationMessage.partyId}
							/>
						</Grid>
					</Grid>
					<Stack direction="row" justifyContent="right" mt={2}>
						<Button
							disabled={isLoading}
							variant="contained"
							type="submit"
							size="large"
							sx={{ width: { xs: '100%', md: 'auto' } }}
						>
							{TitleVariable.SEARCH}
							{isLoading && (
								<CircularProgress
									color="inherit"
									sx={{ marginLeft: '0.625rem' }}
									size="1.5rem"
								/>
							)}
						</Button>
					</Stack>
				</Box>
			</form>
			<CustomSnackbar
				open={openSnackbar}
				message={errorMessage}
				handleOnClose={() => setOpenSnackbar(false)}
			/>
		</>
	);
};
export default makeErrorBoundComponent(PartyIdForm);
