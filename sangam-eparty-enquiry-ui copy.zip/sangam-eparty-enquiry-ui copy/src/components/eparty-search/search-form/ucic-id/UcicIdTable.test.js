import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Provider } from 'react-redux';
import { MockedProvider } from '@apollo/client/testing';
import configureStore from 'redux-mock-store';
import { useNavigate } from 'react-router-dom';
import UcicidTable from './UcicIdTable';
import { GET_QUERY_INDIVIDUAL } from '../../../../utils/epartygqlsearch.service';
import { setError } from '../../../../views/eparty-search/EpartySearch.slice';

const mockStore = configureStore([]);

jest.mock('react-router-dom', () => ({
	...jest.requireActual('react-router-dom'),
	useNavigate: jest.fn(),
}));

describe('UcicidTable Component', () => {
	let store;
	const mockNavigate = jest.fn(); // Create a mock function to track navigation calls
	useNavigate.mockReturnValue(mockNavigate); // Ensure useNavigate returns the mock function

	beforeEach(() => {
		store = mockStore({
			UcicIdSearchSlice: {
				ucicIdSearchData: [{ ucicId: '123', partyId: '456', referenceId: '789' }],
			},
		});
		store.dispatch = jest.fn();
	});

	const renderComponent = (mocks = []) =>
		render(
			<Provider store={store}>
				<MockedProvider mocks={mocks} addTypename={false}>
					<UcicidTable />
				</MockedProvider>
			</Provider>,
		);

	it('renders table with UCIC ID data', () => {
		renderComponent();

		expect(screen.getByText(/Party ID Data/i)).toBeInTheDocument();
		expect(screen.getByText(/UCIC ID/i)).toBeInTheDocument();
		expect(screen.getByText(/Reference ID/i)).toBeInTheDocument();
		expect(screen.getByText(/Action/i)).toBeInTheDocument();
		expect(screen.getByText('123')).toBeInTheDocument();
		expect(screen.getByText('456')).toBeInTheDocument();
		expect(screen.getByText('789')).toBeInTheDocument();
	});

	it('dispatches fetchData and navigates to details page on button click', async () => {
		const mocks = [
			{
				request: {
					query: GET_QUERY_INDIVIDUAL,
					variables: { partyId: '456' },
					context: { clientName: 'party_info' },
				},
				result: {
					data: {
						individualData: {
							/* Mock your data here */
						},
					},
				},
			},
		];

		renderComponent(mocks);

		const viewButton = screen.getByRole('button', { name: /view/i });
		fireEvent.click(viewButton);
	});

	it('shows loading spinner when query is in progress', async () => {
		const mocks = [
			{
				request: {
					query: GET_QUERY_INDIVIDUAL,
					variables: { partyId: '456' },
					context: { clientName: 'party_info' },
				},
				result: new Promise(() => {}), // Keeps the query in a loading state
			},
		];

		renderComponent(mocks);

		const viewButton = screen.getByRole('button', { name: /view/i });
		fireEvent.click(viewButton);
	});

	it('displays an error message in snackbar if query fails', async () => {
		const mocks = [
			{
				request: {
					query: GET_QUERY_INDIVIDUAL,
					variables: { partyId: '456' },
					context: { clientName: 'party_info' },
				},
				error: new Error('Failed to fetch data'),
			},
		];

		renderComponent(mocks);

		const viewButton = screen.getByRole('button', { name: /view/i });
		fireEvent.click(viewButton);

		await waitFor(() => {
			expect(store.dispatch).toHaveBeenCalledWith(setError('Failed to fetch data'));
		});

		expect(screen.getByText(/Failed to fetch data/i)).toBeInTheDocument();
	});

	it('closes the snackbar when close button is clicked', async () => {
		renderComponent();

		store.dispatch(setError('Some error'));

		await waitFor(() => {
			expect(screen.queryByText(/Some error/i)).not.toBeInTheDocument();
		});
	});
});
