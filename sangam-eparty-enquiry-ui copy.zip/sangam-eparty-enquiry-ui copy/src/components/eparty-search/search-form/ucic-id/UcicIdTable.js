import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { useLazyQuery } from '@apollo/client';
import {
	Button,
	Paper,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	Typography,
} from '@mui/material';
import CircularProgress from '@mui/material/CircularProgress';
import VisibilityIcon from '@mui/icons-material/Visibility';
import TitleVariable from '../../../../constants/TitleVariable';
import PATH, { ENDPOINT } from '../../../../constants/Routes';
import { GET_QUERY_INDIVIDUAL } from '../../../../utils/epartygqlsearch.service';
import CustomSnackbar from '../../../custom-alert/CustomSnackbar';
import { setData, setError, setLoading } from '../../../../views/eparty-search/EpartySearch.slice';
import styles from '../../../dil-search/dashboard/DashBoard.module.css';

const UcicidTable = () => {
	const dispatch = useDispatch();
	const navigate = useNavigate();

	const { ucicIdSearchData } = useSelector((state) => state.UcicIdSearchSlice);

	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [errorMessage, setErrorMessage] = useState('');

	const [fetchData, { loading, error, data }] = useLazyQuery(GET_QUERY_INDIVIDUAL);

	useEffect(() => {
		if (loading) {
			dispatch(setLoading());
		} else if (data) {
			dispatch(setData(data));
			navigate(PATH.EPARTY_DETAIL);
		} else if (error) {
			dispatch(setError(error?.message));
			setOpenSnackbar(true);
			setErrorMessage(error?.message);
		}
	}, [loading, error, data, dispatch, navigate]);

	const handleAction = () => {
		const variables = {
			partyId: ucicIdSearchData[0].partyId,
		};
		fetchData({ variables, context: { clientName: ENDPOINT.PARTY_INFO } });
	};
	return (
		<>
			<Paper className={styles.summaryTableMain}>
				<Typography variant="h6" padding={2}>
					{TitleVariable.PARTY_ID_DATA}
				</Typography>
				<TableContainer component={Paper}>
					<Table aria-label="customized table">
						<TableHead className={styles.summaryTableHead}>
							<TableRow>
								<TableCell className={styles.summaryTableCell}>
									{TitleVariable.UCIC_ID}
								</TableCell>
								<TableCell className={styles.summaryTableCell}>
									{TitleVariable.PARTY_ID}
								</TableCell>
								<TableCell className={styles.summaryTableCell}>
									{TitleVariable.REFERENCE_ID}
								</TableCell>
								<TableCell className={styles.summaryTableCell}>
									{TitleVariable.ACTION}
								</TableCell>
							</TableRow>
						</TableHead>
						<TableBody>
							{ucicIdSearchData.length &&
								ucicIdSearchData?.map((row, i) => (
									<TableRow
										key={i}
										sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
									>
										<TableCell>{row.ucicId}</TableCell>
										<TableCell>{row.partyId}</TableCell>
										<TableCell>{row.referenceId}</TableCell>
										<TableCell>
											<Button
												onClick={handleAction}
												variant="contained"
												size="small"
											>
												{loading ? (
													<CircularProgress
														color="inherit"
														sx={{ marginLeft: '0.625rem' }}
														size="1.5rem"
													/>
												) : (
													<>
														<VisibilityIcon />{' '}
														<Typography ml={1} fontSize={14}>
															{TitleVariable.VIEW}
														</Typography>
													</>
												)}
											</Button>
										</TableCell>
									</TableRow>
								))}
						</TableBody>
					</Table>
				</TableContainer>
			</Paper>
			<CustomSnackbar
				open={openSnackbar}
				message={errorMessage}
				handleOnClose={() => setOpenSnackbar(false)}
			/>
		</>
	);
};

export default UcicidTable;
