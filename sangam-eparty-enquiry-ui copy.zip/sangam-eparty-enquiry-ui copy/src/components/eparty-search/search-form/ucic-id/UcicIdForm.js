import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useForm } from 'react-hook-form';
import { Box, Button } from '@mui/material';
import Stack from '@mui/material/Stack';
import Grid from '@mui/material/Grid2';
import CircularProgress from '@mui/material/CircularProgress';
import TitleVariable from '../../../../constants/TitleVariable';
import makeErrorBoundComponent from '../../../error-boundary/make-error-bound-component';
import TextFieldInput from '../../../text-field-input/TextFieldInput';
import CustomSnackbar from '../../../custom-alert/CustomSnackbar';
import {
	fetchPartyDetail,
	resetUcicIdSearch,
} from '../../../../views/eparty-search/UcicIdSearch.slice';
import ThunkApiStatus from '../../../../constants/ThunkApiStatus';
import ValidationMessages from '../../../../constants/ValidationMessage';

const UcicIdForm = () => {
	const dispatch = useDispatch();
	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [errorMessage, setErrorMessage] = useState('');

	const { ucicIdSearchStatus, ucicIdSearchError } = useSelector(
		(state) => state.UcicIdSearchSlice,
	);

	const { handleSubmit, control, watch } = useForm({
		defaultValues: {
			ucicId: '',
		},
	});

	const validationRules = {
		ucicId: {
			required: true,
		},
	};
	const validationMessage = {
		ucicId: {
			required: `${ValidationMessages.UCIC_ID}`,
		},
	};
	const onSubmit = () => {
		dispatch(resetUcicIdSearch());
		const ucicId = watch('ucicId');
		const params = { ucicId };
		dispatch(fetchPartyDetail(params));
	};

	useEffect(() => {
		if (ucicIdSearchStatus === ThunkApiStatus.FAILED) {
			setOpenSnackbar(true);
			setErrorMessage(ucicIdSearchError);
		}
	}, [ucicIdSearchStatus, ucicIdSearchError]);

	const isLoading = ucicIdSearchStatus === ThunkApiStatus.PENDING;

	return (
		<>
			<Box>
				<form onSubmit={handleSubmit(onSubmit)}>
					<Grid container spacing={4}>
						<Grid size={{ xs: 12, md: 6 }}>
							<TextFieldInput
								control={control}
								name="ucicId"
								label="UCIC ID"
								customProps={{ readonly: false }}
								fullWidth
								size="small"
								validationRules={validationRules.ucicId}
								validationMsg={validationMessage.ucicId}
							/>
						</Grid>
					</Grid>
					<Stack direction="row" justifyContent="right" mt={2}>
						<Button
							disabled={isLoading}
							variant="contained"
							type="submit"
							size="large"
							sx={{ width: { xs: '100%', md: 'auto' } }}
						>
							{TitleVariable.SEARCH}
							{isLoading && (
								<CircularProgress
									color="inherit"
									sx={{ marginLeft: '0.625rem' }}
									size="1.5rem"
								/>
							)}
						</Button>
					</Stack>
				</form>
			</Box>
			<CustomSnackbar
				open={openSnackbar}
				message={errorMessage}
				handleOnClose={() => setOpenSnackbar(false)}
			/>
		</>
	);
};

export default makeErrorBoundComponent(UcicIdForm);
