import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import UcicIdForm from './UcicIdForm';
import ThunkApiStatus from '../../../../constants/ThunkApiStatus';
import {
	fetchPartyDetail,
	resetUcicIdSearch,
} from '../../../../views/eparty-search/UcicIdSearch.slice';

const mockStore = configureStore([]);
jest.mock('../../../../views/eparty-search/UcicIdSearch.slice', () => ({
	fetchPartyDetail: jest.fn(),
	resetUcicIdSearch: jest.fn(),
}));

describe('UcicIdForm Component', () => {
	let store;

	beforeEach(() => {
		store = mockStore({
			UcicIdSearchSlice: {
				ucicIdSearchStatus: ThunkApiStatus.IDLE,
				ucicIdSearchError: '',
			},
		});
		store.dispatch = jest.fn();
	});

	const renderComponent = () =>
		render(
			<Provider store={store}>
				<UcicIdForm />
			</Provider>,
		);

	it('renders the form elements correctly', () => {
		renderComponent();

		expect(screen.getByLabelText(/UCIC ID/i)).toBeInTheDocument();
		expect(screen.getByRole('button', { name: /search/i })).toBeInTheDocument();
	});

	it('dispatches resetUcicIdSearch and fetchPartyDetail on form submit', async () => {
		renderComponent();

		const ucicIdInput = screen.getByLabelText(/UCIC ID/i);
		const submitButton = screen.getByRole('button', { name: /search/i });

		fireEvent.change(ucicIdInput, { target: { value: '12345' } });
		fireEvent.click(submitButton);

		await waitFor(() => {
			expect(resetUcicIdSearch).toHaveBeenCalled();
			expect(fetchPartyDetail).toHaveBeenCalledWith({ ucicId: '12345' });
		});
	});

	it('displays a loading spinner when submitting', () => {
		store = mockStore({
			UcicIdSearchSlice: {
				ucicIdSearchStatus: ThunkApiStatus.PENDING,
				ucicIdSearchError: '',
			},
		});
		renderComponent();

		const submitButton = screen.getByRole('button', { name: /search/i });
		expect(submitButton).toBeDisabled();
		expect(screen.getByRole('progressbar')).toBeInTheDocument();
	});

	it('shows an error message in snackbar when search fails', () => {
		store = mockStore({
			UcicIdSearchSlice: {
				ucicIdSearchStatus: ThunkApiStatus.FAILED,
				ucicIdSearchError: 'Search failed',
			},
		});
		renderComponent();

		expect(screen.getByText(/Search failed/i)).toBeInTheDocument();
	});

	it('closes the snackbar when the close button is clicked', async () => {
		renderComponent();

		// Open the snackbar by simulating a failure state
		store.dispatch({
			type: 'UcicIdSearchSlice/failure',
			payload: { error: 'Some error' },
		});

		await waitFor(() => {
			expect(screen.queryByText(/Some error/i)).not.toBeInTheDocument();
		});
	});
});
