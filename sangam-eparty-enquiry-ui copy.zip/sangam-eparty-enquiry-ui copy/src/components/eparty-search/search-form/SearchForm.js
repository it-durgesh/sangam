import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';
import Radio from '@mui/material/Radio';
import { blue, grey } from '@mui/material/colors';
import SearchIcon from '@mui/icons-material/Search';
import { Button, Divider, Typography } from '@mui/material';
import TitleVariable from '../../../constants/TitleVariable';
import { EPARTY_SEARCH_OPTION } from '../../../constants/Common';
import { resetUcicIdSearch } from '../../../views/eparty-search/UcicIdSearch.slice';
import makeErrorBoundComponent from '../../error-boundary/make-error-bound-component';
import UcicidSearch from './ucic-id/UcicIdForm';
import PartyIdForm from './party-id/PartyIdForm';
import UcicidTable from './ucic-id/UcicIdTable';
import styles from './SearchForm.module.css';

const SearchForm = () => {
	const dispatch = useDispatch();
	const radioColorWhite = {
		color: blue[700],
		'&.Mui-checked': {
			color: grey[200],
		},
	};
	const { ucicIdSearchData } = useSelector((state) => state.UcicIdSearchSlice);

	const [selectedValue, setSelectedValue] = useState(EPARTY_SEARCH_OPTION.PARTY_ID);

	const handleChange = (value) => {
		dispatch(resetUcicIdSearch());
		setSelectedValue(value);
	};

	return (
		<Container>
			<Box className={styles.formMainContainer}>
				<Box className={styles.radioContainer}>
					<Button
						className={styles.radioContainerBtn}
						variant={
							selectedValue === EPARTY_SEARCH_OPTION.PARTY_ID
								? 'contained'
								: 'outlined'
						}
						size="large"
						onClick={() => handleChange(EPARTY_SEARCH_OPTION.PARTY_ID)}
					>
						<Box className={styles.btnTxt}>
							<SearchIcon />
							<Typography> {TitleVariable.PARTY_ID}</Typography>
						</Box>
						<Radio
							sx={radioColorWhite}
							checked={selectedValue === EPARTY_SEARCH_OPTION.PARTY_ID}
							className={styles.radioSize}
						/>
					</Button>
					<Button
						className={styles.radioContainerBtn}
						variant={
							selectedValue === EPARTY_SEARCH_OPTION.UCIC_ID
								? 'contained'
								: 'outlined'
						}
						size="large"
						onClick={() => handleChange(EPARTY_SEARCH_OPTION.UCIC_ID)}
					>
						<Box className={styles.btnTxt}>
							<SearchIcon />
							<Typography> {TitleVariable.UCIC_ID} </Typography>
						</Box>
						<Radio
							sx={radioColorWhite}
							checked={selectedValue === EPARTY_SEARCH_OPTION.UCIC_ID}
							className={styles.radioSize}
						/>
					</Button>
				</Box>
				<Divider className={styles.dividerStyle} />
				{selectedValue === EPARTY_SEARCH_OPTION.UCIC_ID ? (
					<UcicidSearch />
				) : (
					<PartyIdForm />
				)}
			</Box>
			{ucicIdSearchData && <UcicidTable />}
		</Container>
	);
};

export default makeErrorBoundComponent(SearchForm);
