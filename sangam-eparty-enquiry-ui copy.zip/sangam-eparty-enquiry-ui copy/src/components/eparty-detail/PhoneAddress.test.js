import { render } from '@testing-library/react';
import PhoneAddress from './PhoneAddress';

describe('Phone Address component ', () => {
	test('calling phone address component', async () => {
		const mobileNumber = [{ mobileTypes: 'smart', countryCode: 91, phoneNumber: 3434232323 }];
		const landLineNumber = [
			{ landLineType: 'land', countryCode: 91, areaCode: 23, phoneNumber: 23232323 },
		];
		const eAddress = [{ emailTypes: 'online', emailId: 'p@gmail.com' }];
		const postalAddress = [{ addressTypes: ['test'] }];
		render(
			<PhoneAddress
				mobileNumber={mobileNumber}
				landLineNumber={landLineNumber}
				eAddress={eAddress}
				postalAddress={postalAddress}
			/>,
		);
	});
});
