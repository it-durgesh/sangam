import React from 'react';
import classNames from 'classnames';
import { Box, Grid2, Card, CardContent, Typography, Tabs, Tab, Skeleton } from '@mui/material';
import TitleVariable, { TitleAccountDetail } from '../../constants/TitleVariable';
import { COMMON } from '../../constants/Common';
import makeErrorBoundComponent from '../error-boundary/make-error-bound-component';
import styles from './Tabs.module.css';

function a11yProps(index) {
	return {
		id: `account-tab-${index}`,
		'aria-controls': `account-tabpanel-${index}`,
	};
}

const CustomTabPanel = (props) => {
	const { children, value, index, ...other } = props;

	return (
		<div
			role="tabpanel"
			hidden={value !== index}
			id={`account-tabpanel-${index}`}
			aria-labelledby={`account-tab-${index}`}
			{...other}
		>
			{value === index && (
				<Box sx={{ p: 3 }} className={styles.tabPanelBox}>
					{children}
				</Box>
			)}
		</div>
	);
};

const AccountDetail = (props) => {
	const { accountData: data } = props;
	const [value, setValue] = React.useState(0);

	const handleChange = (event, newValue) => {
		setValue(newValue);
	};

	const pannelBoxClassName = classNames([styles.boxFlex], [styles.tabPanelInner]);

	return (
		<Grid2 container spacing={2}>
			<Grid2 size={12}>
				<Card>
					<CardContent>
						<Typography variant="h2" className={styles.cardInnerHeading}>
							{TitleVariable.ACCOUNT_DETAILS}
						</Typography>
						<Grid2 container spacing={2}>
							{data ? (
								<Grid2 size={12}>
									<Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
										<Tabs
											value={value}
											onChange={handleChange}
											variant="scrollable"
											scrollButtons="auto"
											aria-label="account details"
											sx={{ backgroundColor: '#e4e4e4' }}
										>
											{data.map((e, i) => (
												<Tab
													key={i}
													{...a11yProps(i)}
													label={COMMON[e.accountType]}
													sx={{ fontWeight: '600' }}
												/>
											))}
										</Tabs>
									</Box>
									{data.map((e, index) => (
										<CustomTabPanel value={value} index={index} key={index}>
											{Object.keys(e)
												.filter((key) => key !== '__typename')
												.map((k, i) => (
													<Box className={pannelBoxClassName} key={i}>
														<Typography
															component="span"
															className={styles.textLeft}
														>
															{TitleAccountDetail[k] || '--'}:
														</Typography>
														<Typography
															variant="body2"
															component="span"
															className={`${styles.textRight} ${
																e[k] === COMMON.ACTIVE &&
																styles.textActive
															}`}
														>
															{e[k] || '--'}
														</Typography>
													</Box>
												))}
										</CustomTabPanel>
									))}
								</Grid2>
							) : (
								<>
									<Skeleton
										variant="rectangular"
										width={100}
										height={60}
										animation="wave"
									/>
									<Skeleton
										variant="rectangular"
										width={100}
										height={60}
										animation="wave"
									/>
									<Skeleton
										variant="rectangular"
										width={100}
										height={60}
										animation="wave"
									/>
									<Skeleton
										variant="rectangular"
										width="100%"
										height={300}
										animation="wave"
									/>
								</>
							)}
						</Grid2>
					</CardContent>
				</Card>
			</Grid2>
		</Grid2>
	);
};
export default makeErrorBoundComponent(AccountDetail);
