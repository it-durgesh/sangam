import React from 'react';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

import {
	Box,
	Card,
	Grid2,
	CardContent,
	Typography,
	Accordion,
	AccordionSummary,
	AccordionDetails,
	Stack,
	Chip,
	Divider,
} from '@mui/material';
import { TitlePhoneAddress } from '../../constants/TitleVariable';
import makeErrorBoundComponent from '../error-boundary/make-error-bound-component';
import styles from './Tabs.module.css';

const PhoneAdress = (props) => {
	const { mobileNumber, landLineNumber, eAddress, postalAddress } = props;
	return (
		<>
			<Grid2 container spacing={2}>
				<Grid2 size={{ xs: 12, md: 6 }}>
					<Card>
						<CardContent>
							<Typography variant="h2" className={styles.cardInnerHeading}>
								{TitlePhoneAddress.PHONE_ADDRESS}
							</Typography>

							{Array.isArray(mobileNumber) && (
								<Grid2 container>
									{mobileNumber.map((mobType, idx) => {
										return (
											<Grid2 size={12} key={idx}>
												<Box className={styles.boxFlex}>
													<Typography
														component="span"
														className={styles.textLeft}
													>
														{mobType.mobileTypes}{' '}
														{TitlePhoneAddress.NUMBER}:
													</Typography>
													<Typography
														variant="body2"
														component="span"
														className={styles.textRight}
													>
														{`${mobType.countryCode} ${mobType.phoneNumber}`}
													</Typography>
												</Box>
											</Grid2>
										);
									})}
								</Grid2>
							)}

							<Divider />
							{Array.isArray(landLineNumber) &&
								landLineNumber.map((landLineType, i) => {
									return (
										<Grid2 size={12} mt={2} key={i}>
											<Box className={styles.boxFlex}>
												<Typography
													component="span"
													className={styles.textLeft}
												>
													{TitlePhoneAddress.LAND_LINE}{' '}
													{landLineType.landlineType}{' '}
													{TitlePhoneAddress.NUMBER}:
												</Typography>
												<Typography
													variant="body2"
													component="span"
													className={styles.textRight}
												>
													{`${landLineType.countryCode} ${landLineType.areaCode} ${landLineType.phoneNumber}`}
												</Typography>
											</Box>
										</Grid2>
									);
								})}
						</CardContent>
					</Card>
				</Grid2>
				<Grid2 size={{ xs: 12, md: 6 }}>
					<Card>
						<CardContent>
							<Typography variant="h2" className={styles.cardInnerHeading}>
								{TitlePhoneAddress.ELE_ADDRESS}
							</Typography>
							<Grid2 container>
								{Array.isArray(eAddress) &&
									eAddress.map((eAddressType, i) => {
										return (
											<Grid2 size={12} key={i}>
												<Box className={styles.boxFlex}>
													<Typography
														component="span"
														className={styles.textLeft}
													>
														{eAddressType.emailTypes}{' '}
														{TitlePhoneAddress.EMAIL_ID}:
													</Typography>
													<Typography
														variant="body2"
														component="span"
														className={styles.textRight}
													>
														{eAddressType.emailId}
													</Typography>
												</Box>
											</Grid2>
										);
									})}
							</Grid2>
						</CardContent>
					</Card>
				</Grid2>
			</Grid2>

			<Grid2 container spacing={2}>
				<Grid2 size={12}>
					<Card sx={{ mt: 2 }}>
						<CardContent>
							<Typography variant="h2" className={styles.cardInnerHeading}>
								{TitlePhoneAddress.POSTAL_ADDRESS}
							</Typography>

							<Box className={styles.accordion}>
								{Array.isArray(postalAddress) &&
									postalAddress.map((addressType, i) => {
										return (
											<Accordion defaultExpanded key={i}>
												<AccordionSummary
													expandIcon={<ExpandMoreIcon />}
													aria-controls="panel1-content"
													id="panel1-header"
													sx={{ backgroundColor: '#edeff3' }}
												>
													<Stack direction="row" spacing={1}>
														{addressType.addressTypes.map((e, idx) => (
															<Chip
																label={e}
																color="primary"
																variant="outlined"
																key={idx}
															/>
														))}
													</Stack>
												</AccordionSummary>
												<AccordionDetails>
													<Box className={styles.boxFlex}>
														<Typography
															component="span"
															className={styles.textLeft}
														>
															{TitlePhoneAddress.ADDRESS}:
														</Typography>
														<Typography
															variant="body2"
															component="span"
															className={styles.textRight}
														>
															{`${addressType?.addressLine1} ${addressType?.addressLine2} ${addressType?.addressLine3} ${addressType?.addressLine4}`}
														</Typography>
													</Box>

													<Grid2 container spacing={2}>
														<Grid2 size={{ xs: 6, md: 4 }}>
															<Box className={styles.boxFlex}>
																<Typography
																	component="span"
																	className={styles.textLeft}
																>
																	{TitlePhoneAddress.COUNTRY}:
																</Typography>
																<Typography
																	variant="body2"
																	component="span"
																	className={styles.textRight}
																>
																	{addressType?.countryLabel ||
																		'--'}{' '}
																	({addressType?.country || '--'})
																</Typography>
															</Box>

															<Box className={styles.boxFlex}>
																<Typography
																	component="span"
																	className={styles.textLeft}
																>
																	{TitlePhoneAddress.CITY}:
																</Typography>
																<Typography
																	variant="body2"
																	component="span"
																	className={styles.textRight}
																>
																	{addressType?.cityLabel || '--'}
																</Typography>
															</Box>
														</Grid2>
														<Grid2 size={{ xs: 6, md: 4 }}>
															<Box className={styles.boxFlex}>
																<Typography
																	component="span"
																	className={styles.textLeft}
																>
																	{TitlePhoneAddress.STATE}:
																</Typography>
																<Typography
																	variant="body2"
																	component="span"
																	className={styles.textRight}
																>
																	{addressType?.stateLabel ||
																		'--'}{' '}
																	({addressType?.state || '--'})
																</Typography>
															</Box>
															<Box className={styles.boxFlex}>
																<Typography
																	component="span"
																	className={styles.textLeft}
																>
																	{TitlePhoneAddress.PIN_CODE}:
																</Typography>
																<Typography
																	variant="body2"
																	component="span"
																	className={styles.textRight}
																>
																	{addressType?.pinCode || '--'}
																</Typography>
															</Box>
														</Grid2>
														<Grid2 size={{ xs: 6, md: 4 }}>
															<Box className={styles.boxFlex}>
																<Typography
																	component="span"
																	className={styles.textLeft}
																>
																	{
																		TitlePhoneAddress.RESIDENCE_TYPE
																	}
																	:
																</Typography>
																<Typography
																	variant="body2"
																	component="span"
																	className={styles.textRight}
																>
																	{addressType?.residenceType ||
																		'--'}
																</Typography>
															</Box>
														</Grid2>
													</Grid2>
												</AccordionDetails>
											</Accordion>
										);
									})}
							</Box>
						</CardContent>
					</Card>
				</Grid2>
			</Grid2>
		</>
	);
};

export default makeErrorBoundComponent(PhoneAdress);
