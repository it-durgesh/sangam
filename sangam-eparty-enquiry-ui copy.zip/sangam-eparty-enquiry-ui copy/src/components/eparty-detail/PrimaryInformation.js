import React from 'react';
import {
	Box,
	Grid2,
	Card,
	CardContent,
	Typography,
	Chip,
	Accordion,
	AccordionSummary,
	Stack,
	AccordionDetails,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

import { TitlePrimaryInformation } from '../../constants/TitleVariable';
import makeErrorBoundComponent from '../error-boundary/make-error-bound-component';
import styles from './Tabs.module.css';

const PrimaryInformation = (props) => {
	const { primaryInfo } = props;
	return (
		<Grid2 container spacing={2}>
			<Grid2 size={{ xs: 12, sm: 7, md: 7 }}>
				<Card>
					<CardContent>
						<Typography variant="h2" className={styles.cardInnerHeading}>
							{TitlePrimaryInformation.BASIC_INFO}
						</Typography>
						<Grid2 container>
							<Grid2 size={{ xs: 12, md: 6 }}>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitlePrimaryInformation.PARTY_TYPE}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{primaryInfo?.partyType || '--'}
									</Typography>
								</Box>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitlePrimaryInformation.SHORT_NAME}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{primaryInfo?.partyName?.shortName || '--'}
									</Typography>
								</Box>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitlePrimaryInformation.PRIORITY_SECTOR_CAT}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{primaryInfo?.prioritySectorCategory || '--'}
									</Typography>
								</Box>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitlePrimaryInformation.CUST_SEGMENT}:
									</Typography>
									<Chip
										size="small"
										label={primaryInfo?.customerSegment || '--'}
										color="primary"
										className={styles.textRight}
									/>
								</Box>
							</Grid2>
							<Grid2 size={{ xs: 12, md: 6 }}>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitlePrimaryInformation.FULL_NAME}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{primaryInfo.partyName?.name.prefix}{' '}
										{primaryInfo.partyName?.name.fullName}
									</Typography>
								</Box>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitlePrimaryInformation.PROFITABILITY_BAND}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{primaryInfo?.profitabilityBand || '--'}
									</Typography>
								</Box>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitlePrimaryInformation.BANK_STAFF}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{primaryInfo.bankStaff ? 'YES' : 'NO'}
									</Typography>
								</Box>
							</Grid2>
						</Grid2>
					</CardContent>
				</Card>
			</Grid2>
			<Grid2 size={{ xs: 12, sm: 5, md: 5 }}>
				<Card>
					<CardContent>
						<Typography variant="h2" className={styles.cardInnerHeading}>
							{TitlePrimaryInformation.FAMILY_DETAILS}
						</Typography>
						<Box className={styles.boxFlex}>
							<Typography component="span" className={styles.textLeft}>
								{TitlePrimaryInformation.FATHER_NAME}:
							</Typography>
							<Typography
								variant="body2"
								component="span"
								className={styles.textRight}
							>
								{`${primaryInfo?.familyName?.fatherName.prefix} ${primaryInfo?.familyName?.fatherName.fullName}`}
							</Typography>
						</Box>
						<Box className={styles.boxFlex}>
							<Typography component="span" className={styles.textLeft}>
								{TitlePrimaryInformation.MOTHER_NAME}:
							</Typography>
							<Typography
								variant="body2"
								component="span"
								className={styles.textRight}
							>
								{`${primaryInfo?.familyName?.motherName.prefix} ${primaryInfo?.familyName?.motherName.fullName}`}
							</Typography>
						</Box>
						<Box className={styles.boxFlex}>
							<Typography component="span" className={styles.textLeft}>
								{TitlePrimaryInformation.SPOUSE_NAME}:
							</Typography>
							<Typography
								variant="body2"
								component="span"
								className={styles.textRight}
							>
								{`${primaryInfo?.familyName?.spouseName.prefix} ${primaryInfo?.familyName?.spouseName.fullName}`}
							</Typography>
						</Box>
					</CardContent>
				</Card>
			</Grid2>
			<Grid2 size={12}>
				<Card>
					<CardContent>
						<Typography variant="h2" className={styles.cardInnerHeading}>
							{TitlePrimaryInformation.DEMOGRAPHICS}
						</Typography>
						<Grid2 container>
							<Grid2 size={{ xs: 6, md: 3 }}>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitlePrimaryInformation.DATE_OF_BIRTH}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{primaryInfo?.birthInformation.dateOfBirth}
									</Typography>
								</Box>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitlePrimaryInformation.GENDER}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{primaryInfo?.gender || '--'}
									</Typography>
								</Box>
							</Grid2>
							<Grid2 size={{ xs: 6, md: 3 }}>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitlePrimaryInformation.CITY_OF_BIRTH}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{primaryInfo?.birthInformation?.cityOfBirthLabel || '--'}
									</Typography>
								</Box>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitlePrimaryInformation.COUNTRY_OF_BIRTH}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{primaryInfo?.birthInformation?.countryOfBirthLabel || '--'}{' '}
										({primaryInfo?.birthInformation?.countryOfBirth})
									</Typography>
								</Box>
							</Grid2>
							<Grid2 size={{ xs: 6, md: 3 }}>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitlePrimaryInformation.MARITAL_STATUS}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{primaryInfo?.maritalStatus || '--'}
									</Typography>
								</Box>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitlePrimaryInformation.RESIDENTIAL_STATUS}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{primaryInfo?.residentialStatus || '--'}
									</Typography>
								</Box>
							</Grid2>

							<Grid2 size={{ xs: 6, md: 3 }}>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitlePrimaryInformation.NATIONALITY}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{primaryInfo?.nationalityLabel || '--'} (
										{primaryInfo?.nationality || '--'})
									</Typography>
								</Box>
							</Grid2>
							<Grid2 size={{ xs: 6, md: 6 }}>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitlePrimaryInformation.POLITICAL_EXPOSURE}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{primaryInfo?.politicalExposure || '--'}
									</Typography>
								</Box>
							</Grid2>
						</Grid2>
					</CardContent>
				</Card>
			</Grid2>
			<Grid2 size={12}>
				<Card>
					<CardContent>
						<Typography variant="h2" className={styles.cardInnerHeading}>
							{TitlePrimaryInformation.EXTENSION_FIELDS}
						</Typography>
						<Box className={styles.boxFlex}>
							<Typography component="span" className={styles.textLeft}>
								{TitlePrimaryInformation.AADHAAR_REDACTED}:
							</Typography>
							<Typography
								variant="body2"
								component="span"
								className={styles.textRight}
							>
								{primaryInfo?.extensionFields?.aadhaarRedacted || '--'}
							</Typography>
						</Box>
						<Box className={styles.boxFlex}>
							<Typography component="span" className={styles.textLeft}>
								{TitlePrimaryInformation.CUST_VINTAGE_DATE}:
							</Typography>
							<Typography
								variant="body2"
								component="span"
								className={styles.textRight}
							>
								{primaryInfo?.extensionFields?.customerVintageDate || '--'}
							</Typography>
						</Box>
						<Grid2 container>
							<Grid2 size={12}>
								<Box className={styles.accordion}>
									{primaryInfo?.extensionFields?.customerExtensions &&
										primaryInfo.extensionFields.customerExtensions.map(
											(cExtension, i) => {
												return (
													<Accordion defaultExpanded key={i}>
														<AccordionSummary
															expandIcon={<ExpandMoreIcon />}
															aria-controls="panel1-content"
															id="panel1-header"
															sx={{ backgroundColor: '#edeff3' }}
														>
															<Stack direction="row" spacing={1}>
																<Chip
																	label={
																		cExtension.externalSystem
																	}
																	color="primary"
																	variant="outlined"
																/>
															</Stack>
														</AccordionSummary>
														<AccordionDetails>
															<Grid2 container spacing={2}>
																<Grid2 size={{ xs: 12, md: 6 }}>
																	<Box className={styles.boxFlex}>
																		<Typography
																			component="span"
																			className={
																				styles.textLeft
																			}
																		>
																			{
																				TitlePrimaryInformation.EXTERNAL_ID
																			}
																			:
																		</Typography>
																		<Typography
																			variant="body2"
																			component="span"
																			className={
																				styles.textRight
																			}
																		>
																			{cExtension?.externalId ||
																				'--'}
																		</Typography>
																	</Box>
																	<Box className={styles.boxFlex}>
																		<Typography
																			component="span"
																			className={
																				styles.textLeft
																			}
																		>
																			{
																				TitlePrimaryInformation.CUST_STATUS
																			}
																			:
																		</Typography>
																		<Typography
																			variant="body2"
																			component="span"
																			className={
																				styles.textRight
																			}
																		>
																			{cExtension?.customerStatus ||
																				'--'}
																		</Typography>
																	</Box>
																	<Box className={styles.boxFlex}>
																		<Typography
																			component="span"
																			className={
																				styles.textLeft
																			}
																		>
																			{
																				TitlePrimaryInformation.EXTERNAL_SYSTEM
																			}
																			:
																		</Typography>
																		<Typography
																			variant="body2"
																			component="span"
																			className={
																				styles.textRight
																			}
																		>
																			{cExtension?.externalSystem ||
																				'--'}
																		</Typography>
																	</Box>
																	<Box className={styles.boxFlex}>
																		<Typography
																			component="span"
																			className={
																				styles.textLeft
																			}
																		>
																			{
																				TitlePrimaryInformation.CUST_CATEGORY
																			}
																			:
																		</Typography>
																		<Typography
																			variant="body2"
																			component="span"
																			className={
																				styles.textRight
																			}
																		>
																			{cExtension?.customerCategory ||
																				'--'}
																		</Typography>
																	</Box>
																</Grid2>
																<Grid2 size={{ xs: 12, md: 6 }}>
																	<Box className={styles.boxFlex}>
																		<Typography
																			component="span"
																			className={
																				styles.textLeft
																			}
																		>
																			{
																				TitlePrimaryInformation.FAMILY_GROUP_CUST_ID
																			}
																			:
																		</Typography>
																		<Typography
																			variant="body2"
																			component="span"
																			className={
																				styles.textRight
																			}
																		>
																			{cExtension?.familyGroupCustomerId ||
																				'--'}
																		</Typography>
																	</Box>
																	<Box className={styles.boxFlex}>
																		<Typography
																			component="span"
																			className={
																				styles.textLeft
																			}
																		>
																			{
																				TitlePrimaryInformation.CUST_STATUS_CHANGE_DATE
																			}
																			:
																		</Typography>
																		<Typography
																			variant="body2"
																			component="span"
																			className={
																				styles.textRight
																			}
																		>
																			{cExtension?.customerStatusChangeDate ||
																				'--'}
																		</Typography>
																	</Box>
																	<Box className={styles.boxFlex}>
																		<Typography
																			component="span"
																			className={
																				styles.textLeft
																			}
																		>
																			{
																				TitlePrimaryInformation.CUST_STATUS_CHANGE_REASON
																			}
																			:
																		</Typography>
																		<Typography
																			variant="body2"
																			component="span"
																			className={
																				styles.textRight
																			}
																		>
																			{cExtension?.customerStatusChangeReason ||
																				'--'}
																		</Typography>
																	</Box>
																</Grid2>
															</Grid2>
														</AccordionDetails>
													</Accordion>
												);
											},
										)}
								</Box>
							</Grid2>
						</Grid2>
					</CardContent>
				</Card>
			</Grid2>
		</Grid2>
	);
};
export default makeErrorBoundComponent(PrimaryInformation);
