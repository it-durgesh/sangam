import { render } from '@testing-library/react';
import RiskProfile from './RiskProfile';

describe('Risk Profile component ', () => {
	test('calling risk profile component', async () => {
		const kycProfile = { riskStatus: 'status' };
		const riskProfile = {
			externalScores: [
				{
					creditBureauName: 'testingBureau',
					bureauScore: 'bureauScore',
					scoreDate: 'scoreDate',
				},
			],
			internalScores: [{ scoreName: 'scoreName', score: 'score' }],
		};
		render(<RiskProfile kycProfile={kycProfile} riskProfile={riskProfile} />);
	});
});
