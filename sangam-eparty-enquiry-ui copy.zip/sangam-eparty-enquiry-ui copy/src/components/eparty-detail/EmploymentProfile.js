import React from 'react';
import {
	Box,
	Grid2,
	Card,
	CardContent,
	Typography,
	TableContainer,
	Paper,
	Table,
	TableHead,
	TableRow,
	TableCell,
	TableBody,
	Stack,
	Chip,
	Collapse,
} from '@mui/material';
import IconButton from '@mui/material/IconButton';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import { convertToString } from '../../utils/commonutil.service';
import { TitleEmploymentProfile } from '../../constants/TitleVariable';
import makeErrorBoundComponent from '../error-boundary/make-error-bound-component';
import styles from './Tabs.module.css';

const Row = (props) => {
	const { row } = props;
	const [open, setOpen] = React.useState(false);
	const showExpandButton =
		row?.professionType ||
		row?.businessType ||
		row?.companyType ||
		row?.annualTurnover ||
		row?.employerType ||
		row?.currentEmploymentDetails;

	return (
		<>
			<TableRow sx={{ '& > *': { borderBottom: 'unset' } }}>
				<TableCell>
					{showExpandButton && (
						<IconButton
							aria-label="expand row"
							size="small"
							onClick={() => setOpen(!open)}
						>
							{open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
						</IconButton>
					)}
				</TableCell>
				<TableCell component="th" scope="row">
					{row.occupationType}
				</TableCell>
				<TableCell>{row.areaOfOccupation || '--'}</TableCell>
			</TableRow>
			<TableRow>
				<TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={6}>
					<Collapse in={open} timeout="auto" unmountOnExit>
						<Box sx={{ margin: 1 }}>
							{row?.professionalType && (
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitleEmploymentProfile.PROFESSION_TYPE}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{row.professionalType}
									</Typography>
								</Box>
							)}
							{row?.businessType && (
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitleEmploymentProfile.BUSINESS_TYPE}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{row.businessType}
									</Typography>
								</Box>
							)}
							{row?.companyType && (
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitleEmploymentProfile.COMPANY_TYPE}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{row.companyType}
									</Typography>
								</Box>
							)}
							{row?.annualTurnover && (
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitleEmploymentProfile.ANNUAL_TURNOVER}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{row.annualTurnover}
									</Typography>
								</Box>
							)}

							{row?.employerType && (
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitleEmploymentProfile.EMPLOYER_TYPE}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{row.employerType}
									</Typography>
								</Box>
							)}
							{row?.currentEmploymentDetails && (
								<>
									<Box className={styles.boxFlex}>
										<Typography component="span" className={styles.textLeft}>
											{TitleEmploymentProfile.EMPLOYER_DETAILS}:
										</Typography>
									</Box>
									<TableContainer component={Paper} mt={2}>
										<Table size="small" aria-label="purchases">
											<TableHead>
												<TableRow>
													<TableCell>
														{TitleEmploymentProfile.EMPLOYER_NAME}
													</TableCell>
													<TableCell>
														{TitleEmploymentProfile.COMPANY_CODE}
													</TableCell>
													<TableCell>
														{TitleEmploymentProfile.DESIGNATION}
													</TableCell>
												</TableRow>
											</TableHead>
											<TableBody>
												<TableRow>
													<TableCell component="th" scope="row">
														{row.currentEmploymentDetails.employerName}
													</TableCell>
													<TableCell>
														{row.currentEmploymentDetails.companyCode}
													</TableCell>
													<TableCell>
														{row.currentEmploymentDetails.designation}
													</TableCell>
												</TableRow>
											</TableBody>
										</Table>
									</TableContainer>
								</>
							)}
						</Box>
					</Collapse>
				</TableCell>
			</TableRow>
		</>
	);
};

const EmploymentProfile = (props) => {
	const { employmentProfile } = props;
	const amlFields = employmentProfile?.extensionFields.amlFields || null;
	return (
		<Grid2 container spacing={2}>
			<Grid2 size={{ xs: 12, sm: 12, md: 6, lg: 6 }} spacing={2}>
				<Grid2 size={12}>
					<Card>
						<CardContent>
							<Typography variant="h2" className={styles.cardInnerHeading}>
								{TitleEmploymentProfile.INCOME_DETAILS}
							</Typography>
							<Box className={styles.boxFlex}>
								<Typography component="span" className={styles.textLeft}>
									{TitleEmploymentProfile.ANNUAL_INCOME}:
								</Typography>
								<Typography
									variant="body2"
									component="span"
									className={styles.textRight}
								>
									{employmentProfile?.annualIncome || '--'}
								</Typography>
							</Box>
							<Box className={styles.boxFlex}>
								<Typography component="span" className={styles.textLeft}>
									{TitleEmploymentProfile.MONTHLY_INCOME}:
								</Typography>
								<Typography
									variant="body2"
									component="span"
									className={styles.textRight}
								>
									{employmentProfile?.monthlyIncome || '--'}
								</Typography>
							</Box>
							<Box className={styles.boxFlex}>
								<Typography component="span" className={styles.textLeft}>
									{TitleEmploymentProfile.INCOME_SOURCES}:
								</Typography>

								<Stack direction="row" spacing={1}>
									{employmentProfile.incomeSources
										? employmentProfile.incomeSources.map((e, i) => (
												<Chip label={e} color="info" key={i} />
											))
										: '--'}
								</Stack>
							</Box>
							<Box className={styles.boxFlex}>
								<Typography component="span" className={styles.textLeft}>
									{TitleEmploymentProfile.NATURE_OF_BUSINESS}:
								</Typography>
								<Typography
									variant="body2"
									component="span"
									className={styles.textRight}
								>
									{convertToString(employmentProfile?.natureOfBusiness)}
								</Typography>
							</Box>
						</CardContent>
					</Card>
				</Grid2>
				{employmentProfile?.occupations && (
					<Grid2 size={12} mt={2}>
						<Card>
							<CardContent>
								<Typography variant="h2" className={styles.cardInnerHeading}>
									{TitleEmploymentProfile.OCCUPATIONS}
								</Typography>
								<TableContainer component={Paper}>
									<Table size="small" aria-label="a dense table">
										<TableHead>
											<TableRow>
												<TableCell />
												<TableCell>{TitleEmploymentProfile.TYPE}</TableCell>
												<TableCell>
													{TitleEmploymentProfile.AREA_OF_OCCUPATION}
												</TableCell>
											</TableRow>
										</TableHead>
										<TableBody>
											{employmentProfile.occupations.map((occ, i) => (
												<Row key={i} row={occ} />
											))}
										</TableBody>
									</Table>
								</TableContainer>
							</CardContent>
						</Card>
					</Grid2>
				)}
			</Grid2>

			<Grid2 size={{ xs: 12, sm: 12, md: 6, lg: 6 }}>
				<Card>
					<CardContent>
						<Typography variant="h2" className={styles.cardInnerHeading}>
							{TitleEmploymentProfile.EXTENSION_FIELDS}
						</Typography>
						<TableContainer component={Paper}>
							<Table size="small" aria-label="a dense table">
								<TableHead>
									<TableRow>
										<TableCell>{TitleEmploymentProfile.NAME}</TableCell>
										<TableCell>{TitleEmploymentProfile.DATA}</TableCell>
									</TableRow>
								</TableHead>
								<TableBody>
									{amlFields &&
										Object.keys(amlFields).map((key, i) => (
											<TableRow
												key={i}
												sx={{
													'&:last-child td, &:last-child th': {
														border: 0,
													},
												}}
											>
												<TableCell className={styles.textLeft}>
													{key}
												</TableCell>
												<TableCell className={styles.textRight}>
													{amlFields[key]}
												</TableCell>
											</TableRow>
										))}
								</TableBody>
							</Table>
						</TableContainer>
					</CardContent>
				</Card>
			</Grid2>
		</Grid2>
	);
};

export default makeErrorBoundComponent(EmploymentProfile);
