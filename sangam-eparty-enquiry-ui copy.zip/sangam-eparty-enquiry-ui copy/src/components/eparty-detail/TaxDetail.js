import React from 'react';
import { Box, Grid2, Card, CardContent, Typography, Stack, Chip } from '@mui/material';
import { TitleTaxDetail } from '../../constants/TitleVariable';
import makeErrorBoundComponent from '../error-boundary/make-error-bound-component';
import styles from './Tabs.module.css';

const TaxDetail = (props) => {
	const { taxProfile, overseasTaxStatus } = props;
	return (
		<Grid2 container spacing={2}>
			<Grid2 size={{ xs: 12, md: 6 }}>
				<Card>
					<CardContent>
						<Typography variant="h2" className={styles.cardInnerHeading}>
							{TitleTaxDetail.TAX_PROFILE}
						</Typography>
						<Grid2 container>
							<Grid2 size={{ xs: 12, md: 6 }}>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitleTaxDetail.PAN_AVAILABLE}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{taxProfile?.panAvailable ? 'YES' : 'NO'}
									</Typography>
								</Box>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitleTaxDetail.PAN}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{taxProfile?.pan || '--'}
									</Typography>
								</Box>
							</Grid2>
							<Grid2 size={{ xs: 12, md: 6 }}>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitleTaxDetail.FORM_AVAILABLE}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{taxProfile.form60Or61Available ? 'YES' : 'NO'}
									</Typography>
								</Box>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitleTaxDetail.PAN_AADHAAR_LINKED}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{taxProfile.panAadhaarLinkages ? 'YES' : 'NO'}
									</Typography>
								</Box>
							</Grid2>
						</Grid2>
					</CardContent>
				</Card>
			</Grid2>
			<Grid2 size={{ xs: 12, md: 6 }}>
				<Card>
					<CardContent>
						<Typography variant="h2" className={styles.cardInnerHeading}>
							{TitleTaxDetail.OVERSEAS_TAX_STATUS}
						</Typography>
						<Box className={styles.boxFlex}>
							<Typography component="span" className={styles.textLeft}>
								{TitleTaxDetail.OVERSEAS_TAX_RESIDENCY}:
							</Typography>
							<Typography
								variant="body2"
								component="span"
								className={styles.textRight}
							>
								{overseasTaxStatus.isOverseasTaxResidencyAvailable ? 'YES' : 'NO'}
							</Typography>
						</Box>
						{overseasTaxStatus.taxResidenciesDetails && (
							<Box className={styles.boxFlex}>
								<Typography component="span" className={styles.textLeft}>
									{TitleTaxDetail.COUNTRY_OF_RESIDENCE}:
								</Typography>

								<Stack direction="row" spacing={1}>
									{overseasTaxStatus.taxResidenciesDetails.map((e, i) => (
										<Chip label={e.countryOfResidence} color="info" key={i} />
									))}
								</Stack>
							</Box>
						)}
					</CardContent>
				</Card>
			</Grid2>
		</Grid2>
	);
};
export default makeErrorBoundComponent(TaxDetail);
