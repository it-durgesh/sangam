import React from 'react';
import {
	Box,
	Grid2,
	Card,
	CardContent,
	Typography,
	Stack,
	Chip,
	Table,
	TableHead,
	TableRow,
	TableCell,
	TableBody,
	TableContainer,
	Paper,
} from '@mui/material';
import CheckIcon from '@mui/icons-material/Check';
import CloseIcon from '@mui/icons-material/Close';
import makeErrorBoundComponent from '../error-boundary/make-error-bound-component';
import { TitlePartyTag } from '../../constants/TitleVariable';
import styles from './Tabs.module.css';

const PartyTag = (props) => {
	const { partyStatuses, partyTag } = props;
	return (
		<Grid2 container spacing={2}>
			<Grid2 size={12}>
				<Card>
					<CardContent>
						<Typography variant="h2" className={styles.cardInnerHeading}>
							{TitlePartyTag.PARTY_TAG_DETAIL}
						</Typography>
						<TableContainer component={Paper}>
							<Table size="small" aria-label="score">
								<TableHead>
									<TableRow>
										<TableCell>{TitlePartyTag.HASH}</TableCell>
										<TableCell>{TitlePartyTag.TAG}</TableCell>
										<TableCell>{TitlePartyTag.PARTY_STATUS}</TableCell>
									</TableRow>
								</TableHead>
								<TableBody>
									{Array.isArray(partyTag?.tagDetails) &&
										partyTag.tagDetails.map((e, i) => (
											<TableRow key={i}>
												<TableCell>{i + 1}</TableCell>
												<TableCell>{e.tag}</TableCell>
												<TableCell>
													{e.isPartyStatus ? (
														<CheckIcon />
													) : (
														<CloseIcon />
													)}
												</TableCell>
											</TableRow>
										))}
								</TableBody>
							</Table>
						</TableContainer>
						<Box className={styles.boxFlex} mt={2}>
							<Typography component="span" className={styles.textLeft}>
								{TitlePartyTag.PARTY_STATUS}:
							</Typography>
							<Stack direction="row" spacing={1}>
								{Array.isArray(partyStatuses) &&
									partyStatuses.map((e, i) => (
										<Chip key={i} label={e} color="info" />
									))}
							</Stack>
						</Box>
					</CardContent>
				</Card>
			</Grid2>
		</Grid2>
	);
};
export default makeErrorBoundComponent(PartyTag);
