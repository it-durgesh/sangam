import { render } from '@testing-library/react';
import PrimaryInformation from './PrimaryInformation';

describe('Primary Information component ', () => {
	test('calling primary information component', async () => {
		const primaryInfo = {
			birthInformation: { dateOfBirth: '25-10-24' },
			extensionFields: { customerExtensions: [{ externalSystem: 'testing' }] },
		};
		render(<PrimaryInformation primaryInfo={primaryInfo} />);
	});
});
