import { render } from '@testing-library/react';
import AccountDetail from './AccountDetail';

describe('Account Detail component ', () => {
	test('calling account detail component', async () => {
		const accountData = [{ sample: 'test1', sample2: 'test2' }];
		render(<AccountDetail accountData={accountData} />);
	});
});
