import React from 'react';
import {
	Box,
	Grid2,
	Card,
	CardContent,
	Typography,
	Table,
	TableHead,
	TableCell,
	TableBody,
	TableRow,
	AccordionDetails,
	AccordionSummary,
	Accordion,
	TableContainer,
	Paper,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { TitleRiskProfile } from '../../constants/TitleVariable';
import makeErrorBoundComponent from '../error-boundary/make-error-bound-component';
import styles from './Tabs.module.css';

const RiskProfile = (props) => {
	const { kycProfile, riskProfile } = props;

	return (
		<Grid2 container spacing={2}>
			<Grid2 size={12}>
				<Card sx={{ mt: 2 }}>
					<CardContent>
						<Typography variant="h2" className={styles.cardInnerHeading}>
							{TitleRiskProfile.RISK_PROFILE}
						</Typography>
						<Grid2 container spacing={2}>
							<Grid2 size={{ xs: 12, md: 4 }}>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitleRiskProfile.KYC_RISK_STATUS}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{kycProfile?.riskStatus || '--'}
									</Typography>
								</Box>
							</Grid2>
							<Grid2 size={{ xs: 12, md: 4 }}>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitleRiskProfile.COUNTRY_OF_INITIAL_RISK}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{riskProfile?.countryOfInitialRisk || '--'}
									</Typography>
								</Box>
							</Grid2>
							<Grid2 size={{ xs: 12, md: 4 }}>
								<Box className={styles.boxFlex}>
									<Typography component="span" className={styles.textLeft}>
										{TitleRiskProfile.COUNTRY_OF_ULTIMATE_RISK}:
									</Typography>
									<Typography
										variant="body2"
										component="span"
										className={styles.textRight}
									>
										{riskProfile?.countryOfUltimateRisk || '--'}
									</Typography>
								</Box>
							</Grid2>

							{Array.isArray(riskProfile.externalScores) && (
								<Grid2 size={12}>
									<TableContainer component={Paper}>
										<Table
											size="small"
											aria-label="score"
											sx={{
												'& .MuiTableCell-sizeSmall': {
													padding: '12px 16px',
												},
											}}
										>
											<TableHead>
												<TableRow>
													<TableCell>
														{TitleRiskProfile.CREDIT_BUREAU_NAME}
													</TableCell>
													<TableCell>
														{TitleRiskProfile.BUREAU_SCORE}
													</TableCell>
													<TableCell>
														{TitleRiskProfile.SCORE_DATA}
													</TableCell>
												</TableRow>
											</TableHead>
											<TableBody>
												{riskProfile.externalScores.map((e, i) => (
													<TableRow key={i}>
														<TableCell>{e.creditBureauName}</TableCell>
														<TableCell>{e.bureauScore}</TableCell>
														<TableCell>{e.scoreDate}</TableCell>
													</TableRow>
												))}
											</TableBody>
										</Table>
									</TableContainer>
								</Grid2>
							)}
						</Grid2>
					</CardContent>
				</Card>
			</Grid2>
			{Array.isArray(riskProfile.internalScores) && (
				<Grid2 size={12}>
					<Accordion defaultExpanded>
						<AccordionSummary
							expandIcon={<ExpandMoreIcon />}
							aria-controls="panel1-content"
							id="panel1-header"
							sx={{ backgroundColor: '#edeff3' }}
						>
							<Typography
								variant="h2"
								className={styles.cardInnerHeading}
								sx={{ marginBottom: '0 !important' }}
							>
								{TitleRiskProfile.INTERNAL_SCORES}
							</Typography>
						</AccordionSummary>
						<AccordionDetails>
							<TableContainer component={Paper}>
								<Table
									size="small"
									aria-label="score"
									sx={{
										'& .MuiTableCell-sizeSmall': {
											padding: '12px 16px',
										},
									}}
								>
									<TableHead>
										<TableRow>
											<TableCell>{TitleRiskProfile.SCORE_NAME}</TableCell>
											<TableCell>{TitleRiskProfile.SCORE}</TableCell>
										</TableRow>
									</TableHead>
									<TableBody>
										{riskProfile.internalScores.map((e, i) => (
											<TableRow key={i}>
												<TableCell className={styles.textLeft}>
													{e.scoreName}
												</TableCell>
												<TableCell className={styles.textRight}>
													{e.score}
												</TableCell>
											</TableRow>
										))}
									</TableBody>
								</Table>
							</TableContainer>
						</AccordionDetails>
					</Accordion>
				</Grid2>
			)}
		</Grid2>
	);
};
export default makeErrorBoundComponent(RiskProfile);
