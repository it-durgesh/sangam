import React from 'react';
import PropTypes from 'prop-types';
import { Tabs, Tab, Box } from '@mui/material';
import AccountBoxIcon from '@mui/icons-material/AccountBox';
import AssignmentIndIcon from '@mui/icons-material/AssignmentInd';
import AccountBalanceIcon from '@mui/icons-material/AccountBalance';
import ContactsIcon from '@mui/icons-material/Contacts';
import SettingsAccessibilityIcon from '@mui/icons-material/SettingsAccessibility';
import BeenhereIcon from '@mui/icons-material/Beenhere';
import CreditScoreIcon from '@mui/icons-material/CreditScore';
import PrimaryInformation from './PrimaryInformation';
import { TitleTabs } from '../../constants/TitleVariable';
import PhoneAdress from './PhoneAddress';
import EmploymentProfile from './EmploymentProfile';
import RiskProfile from './RiskProfile';
import TaxDetail from './TaxDetail';
import PartyTag from './PartyTag';
import AccountDetail from './AccountDetail';
import styles from './Tabs.module.css';

const TabPanel = (props) => {
	const { children, value, index, ...other } = props;

	return (
		<div
			role="tabpanel"
			hidden={value !== index}
			id={`vertical-tabpanel-${index}`}
			aria-labelledby={`vertical-tab-${index}`}
			{...other}
			style={{ width: '82%' }}
			className={styles.tabContentMain}
		>
			{value === index && <Box sx={{ p: 3 }}>{children}</Box>}
		</div>
	);
};

TabPanel.propTypes = {
	children: PropTypes.node,
	index: PropTypes.number.isRequired,
	value: PropTypes.number.isRequired,
};

function a11yProps(index) {
	return {
		id: `vertical-tab-${index}`,
		'aria-controls': `vertical-tabpanel-${index}`,
	};
}

const VerticalTabs = (props) => {
	const { data, accountData, onClickAccount } = props;
	const [value, setValue] = React.useState(0);

	const handleChange = (event, newValue) => {
		setValue(newValue);
	};

	return (
		<Box sx={{ flexGrow: 1, display: 'flex', mt: 4 }}>
			<Tabs
				orientation="vertical"
				variant="scrollable"
				value={value}
				onChange={handleChange}
				aria-label="eparty-search-tab"
				sx={{
					borderRight: 1,
					borderColor: 'divider',
					bgcolor: 'background.paper',
				}}
			>
				<Tab
					label={TitleTabs.PRIMARY_INFORMATION}
					{...a11yProps(0)}
					icon={<AssignmentIndIcon />}
					iconPosition="top"
					sx={{ justifyContent: 'flex-start' }}
				/>
				<Tab
					label={TitleTabs.CONTACT}
					{...a11yProps(1)}
					icon={<ContactsIcon />}
					iconPosition="top"
					sx={{ justifyContent: 'flex-start' }}
				/>
				<Tab
					label={TitleTabs.EMPLOYMENT_PROFILE}
					{...a11yProps(2)}
					icon={<AccountBoxIcon />}
					iconPosition="top"
					sx={{ justifyContent: 'flex-start' }}
				/>
				<Tab
					label={TitleTabs.RISK_PROFILE}
					{...a11yProps(3)}
					icon={<SettingsAccessibilityIcon />}
					iconPosition="top"
					sx={{ justifyContent: 'flex-start' }}
				/>
				<Tab
					label={TitleTabs.TAX_STATUS}
					{...a11yProps(4)}
					icon={<CreditScoreIcon />}
					iconPosition="top"
					sx={{ justifyContent: 'flex-start' }}
				/>
				<Tab
					label={TitleTabs.PARTY_TAG}
					{...a11yProps(5)}
					icon={<BeenhereIcon />}
					iconPosition="top"
					sx={{ justifyContent: 'flex-start' }}
				/>
				<Tab
					label={TitleTabs.ACCOUNT_DTO}
					{...a11yProps(6)}
					icon={<AccountBalanceIcon />}
					iconPosition="top"
					sx={{ justifyContent: 'flex-start' }}
					onClick={onClickAccount}
				/>
			</Tabs>
			<TabPanel value={value} index={0}>
				<PrimaryInformation primaryInfo={data?.jsonContent || null} />
			</TabPanel>
			<TabPanel value={value} index={1}>
				<PhoneAdress
					mobileNumber={data?.phoneAddress?.mobilePhoneNumberDetails || null}
					landLineNumber={data?.phoneAddress?.landlinePhoneNumberDetails || null}
					eAddress={data?.electronicAddress?.emailDetails || null}
					postalAddress={data?.postalAddressDetails?.postalAddressDetails || null}
				/>
			</TabPanel>
			<TabPanel value={value} index={2}>
				<EmploymentProfile employmentProfile={data?.employmentProfile || null} />
			</TabPanel>
			<TabPanel value={value} index={3}>
				<RiskProfile
					kycProfile={data?.kycProfile || null}
					riskProfile={data?.riskProfile || null}
				/>
			</TabPanel>
			<TabPanel value={value} index={4}>
				<TaxDetail
					taxProfile={data.taxProfile}
					overseasTaxStatus={data?.overseasTaxStatus || null}
				/>
			</TabPanel>
			<TabPanel value={value} index={5}>
				<PartyTag
					partyStatuses={data?.partyStatuses || null}
					partyTag={data?.partyTag || null}
				/>
			</TabPanel>
			<TabPanel value={value} index={6}>
				<AccountDetail accountData={accountData || null} />
			</TabPanel>
		</Box>
	);
};

export default VerticalTabs;
