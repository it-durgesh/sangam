import { render } from '@testing-library/react';
import PartyTag from './PartyTag';

describe('Party Tag component ', () => {
	test('calling party tag component', async () => {
		const partyStatuses = ['success'];
		const partyTag = { tagDetails: [{ tag: 'true', isPartyStatus: 'success' }] };

		render(<PartyTag partyStatuses={partyStatuses} partyTag={partyTag} />);
	});
});
