import { render } from '@testing-library/react';
import VerticalTabs from './Tabs';

describe('Vertical Tabs component ', () => {
	test('calling vertical tabs component', async () => {
		const mockOnClick = jest.fn();

		const tabsData = {
			data: { phoneAddress: {} },
			accountData: {},
			onClickAccount: mockOnClick,
		};

		render(<VerticalTabs tabsData={tabsData} />);
	});
});
