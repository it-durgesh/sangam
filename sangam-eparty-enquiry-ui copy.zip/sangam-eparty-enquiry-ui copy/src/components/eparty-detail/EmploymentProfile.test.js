import { render } from '@testing-library/react';
import EmploymentProfile from './EmploymentProfile';

describe('Employment Profile component ', () => {
	test('calling employment profile component', async () => {
		const employmentProfile = {
			occupations: [{ professionType: '' }],
			extensionFields: { amlFields: { key1: 'key1', key2: 'key2' } },
			incomeSources: ['source'],
			natureOfBusiness: 'business',
		};

		render(<EmploymentProfile employmentProfile={employmentProfile} />);
	});
});
