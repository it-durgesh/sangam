import { render } from '@testing-library/react';
import TaxDetail from './TaxDetail';

describe('Tax Detail component ', () => {
	test('calling tax profile component', async () => {
		const overseasTaxStatusObj = { taxResidenciesDetails: [{ countryOfResidence: 'testing' }] };

		render(<TaxDetail taxProfile="tax-profile" overseasTaxStatus={overseasTaxStatusObj} />);
	});
});
