import React, { useMemo } from 'react';
import { FormControl, FormHelperText, Typography } from '@mui/material';
import { DatePicker, DesktopDatePicker } from '@mui/x-date-pickers';
import dayjs from 'dayjs';
import { useController } from 'react-hook-form';
import { dateToString, formatConversion } from '../../utils/datetime.service';
import makeErrorBoundComponent from '../error-boundary/make-error-bound-component';

const inputStyle = {
	desktop: DesktopDatePicker,
	responsive: DatePicker,
};

const DatePickerInput = ({
	id,
	customProps,
	datepickerStyle = 'responsive',
	name,
	control,
	defaultValue,
	minDate = new Date(1900, 0, 1),
	maxDate = new Date(2099, 11, 31),
	validationRules,
	label,
	inputFormat,
	inquiryFormat,
	disabled,
	validationMsg,
	fullWidth,
	width,
	size,
	'aria-label': ariaLabel,
}) => {
	const newValidationRules = useMemo(() => {
		return {
			validate: {
				...(validationRules?.required && {
					required: (value) => {
						return !(value === null);
					},
				}),
				invalidDate: (value) => {
					if (value) return value.toString() !== 'Invalid Date';
				},
				minDate: (value) => {
					if (minDate && value) {
						return value >= minDate;
					}
				},
				maxDate: (value) => {
					if (maxDate && value) return value <= maxDate;
				},
			},
		};
	}, [validationRules, minDate, maxDate]);

	const convertedFormat = useMemo(() => {
		if (inputFormat) return formatConversion(inputFormat);
	}, [inputFormat]);

	const newValidationMsg = {
		...validationMsg,
		invalidDate: 'invalid Date',
		minDate:
			validationMsg && validationMsg.minDate ? validationMsg.minDate : 'date Out Of Range',
		maxDate:
			validationMsg && validationMsg.maxDate ? validationMsg.maxDate : 'date Out Of Range',
	};

	const nullValPlaceHolder =
		customProps.valueProps && customProps.valueProps.nullPlaceHolder
			? customProps.valueProps.nullPlaceHolder
			: '--';
	const InputStyle = inputStyle[datepickerStyle] || inputStyle.responsive;

	const {
		field: { onChange, value },
		fieldState: { error },
	} = useController({
		name,
		control,
		defaultValue,
		rules: newValidationRules,
	});

	return (
		<>
			{customProps && customProps.readonly ? (
				<>
					<Typography variant="body2" color="text.secondary">
						{label}
					</Typography>
					<Typography variant="body1" color="text.primary">
						{value != null
							? dateToString(new Date(value), inquiryFormat || 'dd-MMM-yyyy')
							: nullValPlaceHolder}
					</Typography>
				</>
			) : (
				<FormControl fullWidth={fullWidth}>
					<InputStyle
						label={label}
						value={value ? dayjs(value) : null}
						onChange={(e) => {
							if (e) {
								onChange(dayjs(e).toDate());
							} else onChange(e);
						}}
						slotProps={{
							textField: {
								id,
								size: size || 'medium',
								fullWidth,
								error: error !== undefined,
								...(!label && { inputProps: { 'aria-label': ariaLabel } }),
								inputProps: {
									...(!label && { 'aria-label': ariaLabel }),
									...(disabled && { 'aria-disabled': true }),
									...(validationRules &&
										validationRules.required &&
										!disabled && { 'aria-required': true }),
								},
							},
						}}
						sx={{
							width: width || (fullWidth ? undefined : 220),
						}}
						{...(minDate
							? {
									minDate: dayjs(minDate),
								}
							: null)}
						{...(maxDate
							? {
									maxDate: dayjs(maxDate),
								}
							: null)}
						disabled={disabled}
						format={convertedFormat || 'DD-MM-YYYY'}
					/>
					<FormHelperText error={error !== undefined}>
						{error ? newValidationMsg?.[error.type] : null}
					</FormHelperText>
				</FormControl>
			)}
		</>
	);
};

export default makeErrorBoundComponent(DatePickerInput);
