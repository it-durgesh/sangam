/* eslint-disable react/prop-types */
/* eslint-disable react/jsx-props-no-spreading */
import React, { forwardRef } from 'react';
import ErrorBoundary from './ErrorBoundary';

/**
 * Returns passed component wrapped in ErrorBoundary and verifies that all requiredProps are defined and are the correct type
 * @param {ReactComponent} Component component class/function to be wrapped in ErrorBoundary
 * @returns {Function} react component that has had all required props verified
 */
const makeErrorBoundComponent = (Component) => {
	const name = Component.name || 'Component';
	const errorBoundComponent = forwardRef(({ fallback, report, ...props }, ref) => (
		<ErrorBoundary
			className={`error-boundary--${name.toLowerCase()}`}
			fallback={fallback}
			report={report}
		>
			<Component {...props} ref={ref} />
		</ErrorBoundary>
	));

	// Clones all static properties of Component class onto to the wrapped component
	Object.entries(Component).forEach(([propertyName, propertyValue]) => {
		errorBoundComponent[propertyName] = propertyValue;
	});

	// Sets name of component to show up in React DevTools
	errorBoundComponent.displayName = `ErrorBound${name}`;

	return errorBoundComponent;
};

export default makeErrorBoundComponent;
