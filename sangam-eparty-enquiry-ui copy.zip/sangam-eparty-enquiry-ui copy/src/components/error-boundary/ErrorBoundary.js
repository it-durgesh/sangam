/* eslint-disable react/static-property-placement */
/* eslint-disable react/jsx-props-no-spreading */
import React, { Component } from 'react';
import { func, string, node } from 'prop-types';
import classnames from 'classnames';

export default class ErrorBoundary extends Component {
	static propTypes = {
		/** Additional classname for allow BEM naming in a view */
		className: string,
		/** The render tree to catch errors from */
		children: node.isRequired,
		/**
		 * Custom render function if an error is encountered
		 * @param {Error} error - Error object that was thrown
		 * @param {String} classes - error boundary classes to render on the fallback component
		 */
		fallback: func,
		/** Custom function to handle reporting of encountered errors
		 * @param {Error} error - Error object that was thrown
		 * @param {Object} info - Information about error
		 * @property {string} info.componentStack - Stack trace from error
		 */
		report: func,
	};

	static defaultProps = {
		className: '',
		fallback: null,
		report: null,
	};

	static getDerivedStateFromError(error) {
		return {
			error,
			hasError: true,
		};
	}

	constructor(props) {
		super(props);
		this.state = {
			error: null,
			hasError: false,
		};
	}

	componentDidCatch(error, info) {
		const { report } = this.props;
		if (report) {
			report(error, info);
		} else {
			console.error('Error Boundary: ', info.componentStack); // eslint-disable-line no-console
		}
	}

	render() {
		const { className, children, fallback } = this.props;
		const { hasError, error } = this.state;
		const defaultErrorStyle = {
			border: '1px solid red',
			color: 'red',
			padding: '5px',
		};
		const classes = classnames('error-boundary', 'error-boundary--has-error', className);
		if (hasError) {
			return fallback ? (
				fallback(error, classes)
			) : (
				<div style={defaultErrorStyle} className={classes}>
					<span className="error-boundary__message">Error Boundary: {error.message}</span>
				</div>
			);
		}

		return children;
	}
}
