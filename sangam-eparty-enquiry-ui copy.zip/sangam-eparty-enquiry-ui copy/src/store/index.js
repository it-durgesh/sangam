import { configureStore } from '@reduxjs/toolkit';
import { useDispatch } from 'react-redux';
import EpartySearchSlice from '../views/eparty-search/EpartySearch.slice';
import UcicIdSearchSlice from '../views/eparty-search/UcicIdSearch.slice';
import DilBatchSummarySlice from '../views/dil-search/DilBatchSummary.slice';
import DilBatchStatusSlice from '../views/dil-search/DilBatchStatus.slice';

export const store = configureStore({
	reducer: {
		EpartySearchSlice,
		UcicIdSearchSlice,
		DilBatchSummarySlice,
		DilBatchStatusSlice,
	},
});
export const useAppDispatch = () => useDispatch();
