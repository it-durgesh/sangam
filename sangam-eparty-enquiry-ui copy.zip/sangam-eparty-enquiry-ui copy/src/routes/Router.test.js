import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { ApolloProvider } from '@apollo/client';
import AppRouter from './Router';
import * as Routes from '../constants/Routes';
import customApiClient from '../utils/apigraphqlclient.services';

jest.mock(
	'../views/eparty-search',
	() =>
		function () {
			return <div>Eparty Search Page</div>;
		},
);
jest.mock(
	'../views/eparty-detail',
	() =>
		function () {
			return <div>Eparty Detail Page</div>;
		},
);
jest.mock(
	'../views/dil-search',
	() =>
		function () {
			return <div>DIL Search Page</div>;
		},
);
jest.mock(
	'../views/dil-search-detail',
	() =>
		function () {
			return <div>DIL Search Detail Page</div>;
		},
);
jest.mock(
	'../views/general-pages/page-not-found',
	() =>
		function () {
			return <div>Page Not Found</div>;
		},
);
jest.mock(
	'../components/loader',
	() =>
		function () {
			return <div>Loading...</div>;
		},
);
jest.mock(
	'../layouts/MainLayout',
	() =>
		function ({ children, title }) {
			return (
				<div>
					<h1>{title}</h1>
					{children}
				</div>
			);
		},
);

describe('AppRouter', () => {
	it('should render the loader while components are loading', async () => {
		render(
			<ApolloProvider client={customApiClient}>
				<AppRouter />
			</ApolloProvider>,
		);

		expect(screen.getByText('Loading...')).toBeInTheDocument();
	});

	it('should render Eparty Search page on root path', async () => {
		window.history.pushState({}, 'Eparty Search', Routes.ROOT);
		render(
			<ApolloProvider client={customApiClient}>
				<AppRouter />
			</ApolloProvider>,
		);
	});

	it('should render Eparty Detail page on eparty detail path', async () => {
		window.history.pushState({}, 'Eparty Detail', Routes.EPARTY_DETAIL);
		render(
			<ApolloProvider client={customApiClient}>
				<AppRouter />
			</ApolloProvider>,
		);
	});

	it('should render DIL Search page on DIL path', async () => {
		window.history.pushState({}, 'DIL Search', Routes.DIL);
		render(
			<ApolloProvider client={customApiClient}>
				<AppRouter />
			</ApolloProvider>,
		);
	});

	it('should render DIL Search Detail page on DIL search detail path', async () => {
		window.history.pushState({}, 'DIL Search Detail', Routes.DIL_SEARCH_DETAIL);
		render(
			<ApolloProvider client={customApiClient}>
				<AppRouter />
			</ApolloProvider>,
		);
	});

	it('should render Page Not Found on invalid path', async () => {
		window.history.pushState({}, 'Invalid Page', '/invalid-path');
		render(
			<ApolloProvider client={customApiClient}>
				<AppRouter />
			</ApolloProvider>,
		);
	});
});
