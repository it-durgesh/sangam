import React, { Suspense } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Path from '../constants/Routes';
import Loader from '../components/loader';
import Title from '../constants/HeaderTitle';
import MainLayout from '../layouts/MainLayout';

const EpartSearch = React.lazy(() => import('../views/eparty-search'));

const EpartyDetail = React.lazy(() => import('../views/eparty-detail'));

const DilSearch = React.lazy(() => import('../views/dil-search'));

const DilSearchDetail = React.lazy(() => import('../views/dil-search-detail'));

const PageNotFound = React.lazy(() => import('../views/general-pages/page-not-found'));

const GuardedRoute = (Child, title) => {
	return (
		<MainLayout title={title}>
			<Child />
		</MainLayout>
	);
};

const AppRouter = () => {
	return (
		<div
			style={{
				height: '100vh',
				position: 'relative',
				backgroundColor: '#F4F8FB',
				overflow: 'auto',
			}}
		>
			<Router>
				<Suspense fallback={<Loader />}>
					<Routes>
						<Route
							exact
							path={`${Path.ROOT}`}
							element={GuardedRoute(EpartSearch, Title.EPARTY_SERACH)}
						/>
						<Route
							exact
							path={`${Path.EPARTY_DETAIL}`}
							element={GuardedRoute(EpartyDetail, Title.EPARTY_DETAIL)}
						/>
						<Route
							exact
							path={`${Path.DIL}`}
							element={GuardedRoute(DilSearch, Title.DIL)}
						/>
						<Route
							exact
							path={`${Path.DIL_SEARCH_DETAIL}`}
							element={GuardedRoute(DilSearchDetail, Title.DIL)}
						/>
						<Route
							exact
							path={`${Path.DIL}`}
							element={GuardedRoute(PageNotFound, Title.DIL)}
						/>

						<Route path="*" element={GuardedRoute(PageNotFound, Title.NOT_FOUND)} />
					</Routes>
				</Suspense>
			</Router>
		</div>
	);
};

export default AppRouter;
