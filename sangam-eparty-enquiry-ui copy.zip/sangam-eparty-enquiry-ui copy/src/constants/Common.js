import createEnum from '../utils/create-enum';

export const COMMON = createEnum({
	LOAN: 'LOAN',
	DEMAT: 'DEMAT',
	RECURRING_DEPOSIT: 'RECURRING DEPOSIT',
	CASA: 'CASA',
	CREDIT_CARD: 'CREDIT CARD',
	TERM_DEPOSIT: 'TERM DEPOSIT',
	ACTIVE: 'ACTIVE',
});

export const EPARTY_SEARCH_OPTION = createEnum({
	PARTY_ID: 'partyId',
	UCIC_ID: 'ucicId',
});

export const PARTY_TYPE = createEnum({
	INDIVIDUAL: 'INDIVIDUAL',
	NON_INDIVIDUAL: 'NON INDIVIDUAL',
});
