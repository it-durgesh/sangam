import createEnum from '../utils/create-enum';

const ValidationMessages = createEnum({
	batchId: 'Batch Id is required',
	businessDate: 'Business Date is required',
	referenceId: 'Reference Id is required',
	partyType: 'Party type is required',
	partyId: 'Party Id is required',
	ucicId: 'UCIC ID is required',
});

export default ValidationMessages;
