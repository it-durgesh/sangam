import createEnum from '../utils/create-enum';

export default createEnum({
	NOT_FOUND: 'Page not found',
	EPARTY_SERACH: 'Eparty Search',
	DIL: 'DIL Search',
	EPARTY_DETAIL: 'Eparty Detail',
});
