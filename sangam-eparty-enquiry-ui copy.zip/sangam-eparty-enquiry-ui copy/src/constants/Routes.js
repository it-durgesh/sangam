import createEnum from '../utils/create-enum';

export default createEnum({
	ROOT: '/',
	DIL: '/dil',
	EPARTY_SEARCH_LIST: '/eparty-search-list',
	EPARTY_DETAIL: '/eparty-detail',
	DIL_SEARCH_DETAIL: '/dil/search',
	// Errors
});

export const ENDPOINT = createEnum({
	PARTY_INFO: 'party-primary-information-read/graphql',
	PARTY_ACCOUNT: 'party-account-relationship-read/graphql',
});
