import createEnum from '../utils/create-enum';

const TitleVariable = createEnum({
	status: 'Status',
	partyId: 'Party Id',
	search: 'Search',
	goBack: 'Go Back',
	requestPayload: 'Request Payload',
	responsePayload: 'Response Payload',
	batchStatus: 'Batch Status',
	ucicId: 'UCIC ID',
	referenceId: 'Reference ID',
	action: 'Action',
	requestHeader: 'Request Header',
	requestBody: 'Request Body',
	value: 'Value',
	businessDate: 'Business Date',
	view: 'View',
	partyIdData: 'Party Id Data',
	searchByRefId: 'Search By Reference Id',
	accountDetails: 'Account Details',
});

export const TitleAccountDetail = createEnum({
	id: 'Id',
	createdOn: 'Created On',
	createdBy: 'Created By',
	updatedOn: 'Updated On',
	updatedBy: 'Updated By',
	version: 'Version',
	status: 'Status',
	partyId: 'Party Id',
	accountId: 'Account Id',
	accountType: 'Account Type',
	partyRole: 'Party Role',
});

export const TitleEmploymentProfile = createEnum({
	professionType: 'Profession Type',
	businessType: 'Business Type',
	companyType: 'Company Type',
	annualTurnover: 'Annual Turnover',
	employerType: 'Employer Type',
	employerDetails: 'Employer Details',
	employerName: 'Employer Name',
	companyCode: 'Company Code',
	designation: 'Designation',
	incomeDetails: 'Income Details',
	annualIncome: 'Annual Income',
	monthlyIncome: 'Monthly Income',
	incomeSources: 'Income Sources',
	natureOfBusiness: 'Nature Of Business',
	occupations: 'Occupations',
	type: 'Type',
	areaOfOccupation: 'Area of Occupation',
	extensionFields: 'Extension Fields',
	name: 'Name',
	data: 'Data',
});

export const TitlePartyTag = createEnum({
	partyTagDetail: 'Party Tag Detail',
	tag: 'Tag',
	partyStatus: 'Party Status',
	hash: '#',
});

export const TitlePhoneAddress = createEnum({
	phoneAddress: 'Phone address',
	number: 'NUMBER',
	landLine: 'LANDLINE',
	eleAddress: 'Electronic address',
	emailId: 'EMAIL ID',
	postalAddress: 'Postal address',
	address: 'Address',
	country: 'Country',
	city: 'City',
	state: 'State',
	pinCode: 'Pin Code',
	residenceType: 'Residence Type',
});

export const TitlePrimaryInformation = createEnum({
	basicInfo: 'Basic Information',
	partyType: 'Party Type',
	shortName: 'Short Name',
	prioritySectorCat: 'Priority Sector Category',
	custSegment: 'Customer Segment',
	fullName: 'Full Name',
	profitabilityBand: 'Profitability Band',
	bankStaff: 'Bank Staff',
	familyDetails: 'Family Details',
	fatherName: 'Father Name',
	motherName: 'Mother Name',
	spouseName: 'Spouse Name',
	demographics: 'Demographics',
	dateOfBirth: 'Date Of Birth',
	gender: 'Gender',
	cityOfBirth: 'City Of Birth',
	countryOfBirth: 'Country Of Birth',
	maritalStatus: 'Marital Status',
	residentialStatus: 'Residential Status',
	nationality: 'Nationality',
	politicalExposure: 'Political Exposure',
	extensionFields: 'Extension Fields Detail',
	custVintageDate: 'Customer Vintage Date',
	externalId: 'External Id',
	custStatus: 'Customer Status',
	externalSystem: 'External System',
	custCategory: 'Customer Category',
	familyGroupCustId: 'Family Group Customer Id',
	custStatusChangeDate: 'Customer Status Change Date',
	custStatusChangeReason: 'Customer Status Change Reason',
	aadhaarRedacted: 'Aadhaar Redacted',
});

export const TitleRiskProfile = createEnum({
	riskProfile: 'Risk profile',
	kycRiskStatus: 'KYC Risk Status',
	countryOfInitialRisk: 'Country Of Initial Risk',
	countryOfUltimateRisk: 'Country Of Ultimate Risk',
	creditBureauName: 'Credit Bureau Name',
	bureauScore: 'Bureau Score',
	scoreData: 'Score Data',
	internalScores: 'Internal Scores',
	scoreName: 'Score Name',
	score: 'Score',
});

export const TitleTabs = createEnum({
	accountDto: 'Account DTO',
	primaryInformation: 'Primary info',
	contact: 'Contacts Detail',
	employmentProfile: 'Employment profile',
	riskProfile: 'Risk profile',
	taxStatus: 'Tax status',
	partyTag: 'Party tag',
});

export const TitleTaxDetail = createEnum({
	taxProfile: 'Tax Profile',
	overseasTaxStatus: 'Overseas tax status',
	panAvailable: 'PAN Available',
	pan: 'PAN',
	formAvailable: 'Form 60 Or 61 Available',
	panAadhaarLinked: 'PAN Aadhaar Linked',
	overseasTaxResidency: 'Is Overseas Tax Residency Available',
	countryOfResidence: 'Country Of Residence',
});

export default TitleVariable;
