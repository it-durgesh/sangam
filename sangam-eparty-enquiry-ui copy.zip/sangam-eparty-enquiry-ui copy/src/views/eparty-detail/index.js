import EpartyDetail from './EpartyDetail';

export default EpartyDetail;
