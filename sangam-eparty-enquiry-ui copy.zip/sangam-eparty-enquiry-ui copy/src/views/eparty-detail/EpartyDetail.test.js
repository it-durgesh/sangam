import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { Provider } from 'react-redux';
import { BrowserRouter as Router } from 'react-router-dom';
import { MockedProvider } from '@apollo/client/testing';
import configureStore from 'redux-mock-store';
import EpartyDetail from './EpartyDetail';
import {
	setAccountData,
	setAccountError,
	setAccountLoading,
} from '../eparty-search/EpartySearch.slice';
import { GET_QUERY_PARTY_ACCOUNT } from '../../utils/epartygqlsearch.service';
import PATH from '../../constants/Routes';

const mockSearchData = { id: '1', name: 'Party 1' };
const mockAccountData = { id: '1', accountInfo: 'Account Info' };

const mockStore = configureStore([]);
const store = mockStore({
	EpartySearchSlice: {
		searchData: mockSearchData,
		accountData: null,
	},
});

const mocks = [
	{
		request: {
			query: GET_QUERY_PARTY_ACCOUNT,
			variables: { partyId: '1' },
		},
		result: {
			data: { partyAccount: mockAccountData },
		},
	},
];

describe('EpartyDetail Component', () => {
	beforeEach(() => {
		store.clearActions();
	});

	it('renders without crashing', () => {
		render(
			<Provider store={store}>
				<MockedProvider mocks={mocks} addTypename={false}>
					<Router>
						<EpartyDetail />
					</Router>
				</MockedProvider>
			</Provider>,
		);
	});

	it('navigates to the root path if searchData is not available', () => {
		store.getState().EpartySearchSlice.searchData = null;

		const { container } = render(
			<Provider store={store}>
				<MockedProvider mocks={mocks} addTypename={false}>
					<Router>
						<EpartyDetail />
					</Router>
				</MockedProvider>
			</Provider>,
		);

		expect(container.innerHTML).toBe(
			'<div class="MuiContainer-root MuiContainer-maxWidthXl css-hhdjsd-MuiContainer-root"></div>',
		);
	});

	it('dispatches setAccountLoading when loading', async () => {
		render(
			<Provider store={store}>
				<MockedProvider mocks={mocks} addTypename={false}>
					<Router>
						<EpartyDetail />
					</Router>
				</MockedProvider>
			</Provider>,
		);
	});
});
