import React, { useEffect, useState } from 'react';
import Container from '@mui/material/Container';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { useLazyQuery } from '@apollo/client';
import {
	setAccountData,
	setAccountError,
	setAccountLoading,
} from '../eparty-search/EpartySearch.slice';
import PATH, { ENDPOINT } from '../../constants/Routes';
import VerticalTabs from '../../components/eparty-detail/Tabs';
import CustomSnackbar from '../../components/custom-alert/CustomSnackbar';
import makeErrorBoundComponent from '../../components/error-boundary/make-error-bound-component';
import { GET_QUERY_PARTY_ACCOUNT } from '../../utils/epartygqlsearch.service';

const EpartyDetail = () => {
	const dispatch = useDispatch();
	const navigate = useNavigate();
	const { searchData, accountData } = useSelector((state) => state.EpartySearchSlice);

	const [openSnackbar, setOpenSnackbar] = useState(false);
	const [errorMessage, setErrorMessage] = useState('');

	const [fetchAcData, { loading, error, data }] = useLazyQuery(GET_QUERY_PARTY_ACCOUNT);

	useEffect(() => {
		if (!searchData) {
			navigate(PATH.ROOT);
		}
	}, [searchData, navigate]);

	useEffect(() => {
		if (loading) {
			dispatch(setAccountLoading());
		} else if (data) {
			dispatch(setAccountData(data));
		} else if (error) {
			dispatch(setAccountError(error?.message));
			setOpenSnackbar(true);
			setErrorMessage(error?.message);
		}
	}, [loading, error, data, dispatch]);

	const getAccountDetail = () => {
		const partyId = searchData.id;
		if (!accountData && partyId) {
			const variables = {
				partyId,
			};
			fetchAcData({
				variables,
				context: { clientName: ENDPOINT.PARTY_ACCOUNT },
			});
		}
	};

	return (
		<Container maxWidth="xl">
			{searchData && (
				<VerticalTabs
					data={searchData}
					accountData={accountData}
					onClickAccount={getAccountDetail}
				/>
			)}
			<CustomSnackbar
				open={openSnackbar}
				message={errorMessage}
				handleOnClose={() => setOpenSnackbar(false)}
			/>
		</Container>
	);
};

export default makeErrorBoundComponent(EpartyDetail);
