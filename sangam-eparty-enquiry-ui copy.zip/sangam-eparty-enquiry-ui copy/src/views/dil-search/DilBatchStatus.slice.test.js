import { configureStore } from '@reduxjs/toolkit';
import reducer, {
	fetchBatchStatus,
	fetchByReferenceId,
	resetDilBatchStatus,
	initialState,
} from './DilBatchStatus.slice';
import ThunkApiStatus from '../../constants/ThunkApiStatus';
import requestInstance from '../../utils/apiclient.services';
import { handleErrorResponse } from '../../utils/handleerror.services';

// Mock dependencies
jest.mock('../../utils/apiclient.services');
jest.mock('../../utils/handleerror.services');

describe('DilBatchStatusSlice', () => {
	let store;

	beforeEach(() => {
		store = configureStore({
			reducer: {
				dilBatchStatus: reducer,
			},
		});
	});

	afterEach(() => {
		jest.clearAllMocks();
	});

	describe('extraReducers', () => {
		it('should handle fetchBatchStatus.pending', async () => {
			const action = fetchBatchStatus.pending();
			const state = reducer(initialState, action);

			expect(state.batchStatus).toBe(ThunkApiStatus.PENDING);
			expect(state.batchStatusData).toBeNull();
			expect(state.batchStatusError).toBeNull();
		});

		it('should handle fetchBatchStatus.fulfilled', async () => {
			const mockData = { data: 'test data' };
			requestInstance.post.mockResolvedValueOnce({ data: 'test data' });
			const result = await store.dispatch(fetchBatchStatus());

			const state = store.getState().dilBatchStatus;
			expect(state.batchStatus).toBe(ThunkApiStatus.SUCCEEDED);
			expect(state.batchStatusData).toEqual(mockData.data);
			expect(state.batchStatusError).toBeNull();
		});

		it('should handle fetchBatchStatus.rejected', async () => {
			const mockError = 'Request failed';
			handleErrorResponse.mockReturnValueOnce(mockError);
			requestInstance.post.mockRejectedValueOnce(new Error('Network Error'));

			await store.dispatch(fetchBatchStatus());

			const state = store.getState().dilBatchStatus;
			expect(state.batchStatus).toBe(ThunkApiStatus.FAILED);
			expect(state.batchStatusError).toBe(mockError);
			expect(state.batchStatusData).toBeNull();
		});

		it('should handle fetchByReferenceId.pending', async () => {
			const action = fetchByReferenceId.pending();
			const state = reducer(initialState, action);

			expect(state.referenceIdStatus).toBe(ThunkApiStatus.PENDING);
			expect(state.referenceIdData).toBeNull();
			expect(state.referenceIdError).toBeNull();
		});

		it('should handle fetchByReferenceId.fulfilled', async () => {
			const mockData = { data: 'reference id data' };
			requestInstance.post.mockResolvedValueOnce({ data: 'reference id data' });
			const result = await store.dispatch(fetchByReferenceId());

			const state = store.getState().dilBatchStatus;
			expect(state.referenceIdStatus).toBe(ThunkApiStatus.SUCCEEDED);
			expect(state.referenceIdData).toEqual(mockData.data);
			expect(state.referenceIdError).toBeNull();
		});

		it('should handle fetchByReferenceId.rejected', async () => {
			const mockError = 'Reference ID request failed';
			handleErrorResponse.mockReturnValueOnce(mockError);
			requestInstance.post.mockRejectedValueOnce(new Error('Network Error'));

			await store.dispatch(fetchByReferenceId());

			const state = store.getState().dilBatchStatus;
			expect(state.referenceIdStatus).toBe(ThunkApiStatus.FAILED);
			expect(state.referenceIdError).toBe(mockError);
			expect(state.referenceIdData).toBeNull();
		});
	});

	describe('reducers', () => {
		it('should reset state on resetDilBatchStatus', () => {
			const modifiedState = {
				...initialState,
				batchStatus: ThunkApiStatus.SUCCEEDED,
				batchStatusData: { data: 'sample' },
			};
			const state = reducer(modifiedState, resetDilBatchStatus());

			expect(state).toEqual(initialState);
		});
	});
});
