import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import ThunkApiStatus from '../../constants/ThunkApiStatus';
import requestInstance from '../../utils/apiclient.services';
import handleErrorResponse from '../../utils/handleerror.services';

export const initialState = {
	batchId: null,
	businessDate: null,
	batchSummaryStatus: ThunkApiStatus.IDLE,
	batchSummaryData: null,
	batchSummaryError: null,
};

export const fetchBatchSummary = createAsyncThunk('fetchBatchSummary', async (params, thunkAPI) => {
	try {
		const response = await requestInstance
			.get(`/batch-summary/${params.batchId}/${params.businessDate}`)
			.then((res) => {
				if (!res?.data.length) {
					throw new Error('No data found');
				}
				return {
					data: res.data,
				};
			});
		thunkAPI.dispatch(setBatchIdWithDate(params));
		return response;
	} catch (error) {
		const err = handleErrorResponse(error);
		return thunkAPI.rejectWithValue(err);
	}
});

export const DilBatchSummarySlice = createSlice({
	name: 'DilBatchSummarySlice',
	initialState,
	reducers: {
		resetBatchSummary: () => initialState,
		setBatchIdWithDate: (state, action) => {
			state.batchId = action.payload.batchId;
			state.businessDate = action.payload.businessDate;
		},
	},
	extraReducers: (builder) => {
		builder.addCase(fetchBatchSummary.pending, (state) => {
			state.batchSummaryStatus = ThunkApiStatus.PENDING;
		});
		builder.addCase(fetchBatchSummary.fulfilled, (state, action) => {
			state.batchSummaryStatus = ThunkApiStatus.SUCCEEDED;
			state.batchSummaryData = action.payload.data;
		});
		builder.addCase(fetchBatchSummary.rejected, (state, action) => {
			state.batchSummaryStatus = ThunkApiStatus.FAILED;
			state.batchSummaryError = action.payload;
		});
	},
});
export const { resetBatchSummary, setBatchIdWithDate } = DilBatchSummarySlice.actions;
export default DilBatchSummarySlice.reducer;
