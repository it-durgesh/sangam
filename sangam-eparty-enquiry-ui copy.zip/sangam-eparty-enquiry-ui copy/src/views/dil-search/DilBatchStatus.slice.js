import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import ThunkApiStatus from '../../constants/ThunkApiStatus';
import requestInstance from '../../utils/apiclient.services';
import handleErrorResponse from '../../utils/handleerror.services';

export const initialState = {
	batchStatus: ThunkApiStatus.IDLE,
	batchStatusData: null,
	batchStatusError: null,
	referenceIdStatus: ThunkApiStatus.IDLE,
	referenceIdData: null,
	referenceIdError: null,
};

export const fetchBatchStatus = createAsyncThunk('fetchBatchStatus', async (request, thunkAPI) => {
	try {
		const response = await requestInstance.post('/batch-status', request).then((res) => {
			if (!res?.data.length) {
				throw new Error('No data found');
			}
			return {
				data: res.data,
			};
		});
		return response;
	} catch (error) {
		const err = handleErrorResponse(error);
		return thunkAPI.rejectWithValue(err);
	}
});

export const fetchByReferenceId = createAsyncThunk(
	'fetchByReferenceId',
	async (request, thunkAPI) => {
		try {
			const response = await requestInstance.post('/search', request).then((res) => {
				if (!res?.data.length) {
					throw new Error('No data found');
				}
				return {
					data: res.data,
				};
			});
			return response;
		} catch (error) {
			const err = handleErrorResponse(error);
			return thunkAPI.rejectWithValue(err);
		}
	},
);

export const DilBatchStatusSlice = createSlice({
	name: 'DilBatchStatusSlice',
	initialState,
	reducers: {
		resetDilBatchStatus: () => initialState,
	},
	extraReducers: (builder) => {
		builder.addCase(fetchBatchStatus.pending, (state) => {
			state.batchStatus = ThunkApiStatus.PENDING;
		});
		builder.addCase(fetchBatchStatus.fulfilled, (state, action) => {
			state.batchStatus = ThunkApiStatus.SUCCEEDED;
			state.batchStatusData = action.payload.data;
		});
		builder.addCase(fetchBatchStatus.rejected, (state, action) => {
			state.batchStatus = ThunkApiStatus.FAILED;
			state.batchStatusError = action.payload;
		});
		builder.addCase(fetchByReferenceId.pending, (state) => {
			state.referenceIdStatus = ThunkApiStatus.PENDING;
		});
		builder.addCase(fetchByReferenceId.fulfilled, (state, action) => {
			state.referenceIdStatus = ThunkApiStatus.SUCCEEDED;
			state.referenceIdData = action.payload.data;
		});
		builder.addCase(fetchByReferenceId.rejected, (state, action) => {
			state.referenceIdStatus = ThunkApiStatus.FAILED;
			state.referenceIdError = action.payload;
		});
	},
});
export const { resetDilBatchStatus } = DilBatchStatusSlice.actions;
export default DilBatchStatusSlice.reducer;
