import React from 'react';
import { useSelector } from 'react-redux';
import SearchForm from '../../components/dil-search/search-form/SearchForm';
import makeErrorBoundComponent from '../../components/error-boundary/make-error-bound-component';
import DashBoard from '../../components/dil-search/dashboard/DashBoard';
import ThunkApiStatus from '../../constants/ThunkApiStatus';

const DilSearch = () => {
	const { batchSummaryStatus } = useSelector((state) => state.DilBatchSummarySlice);

	if (batchSummaryStatus === ThunkApiStatus.SUCCEEDED) {
		return <DashBoard />;
	}

	return <SearchForm />;
};
export default makeErrorBoundComponent(DilSearch);
