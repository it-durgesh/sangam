import { render } from '@testing-library/react';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import { configureStore } from '@reduxjs/toolkit';
import ThunkApiStatus from '../../constants/ThunkApiStatus';
import DilSearch from './DILSearch';

const createMockStore = (state) => {
	return configureStore({
		reducer: {
			DilBatchSummarySlice: jest.fn().mockReturnValue(state.DilBatchSummarySlice),
		},
	});
};

describe('DilSearch component ', () => {
	test('calling dil search component', async () => {
		const initialState = {
			DilBatchSummarySlice: {
				batchId: 123,
				batchSummaryStatus: ThunkApiStatus.SUCCEEDED,
				businessDate: '2024-11-08',
				batchSummaryData: [
					{ status: 'Completed', count: 10 },
					{ status: 'Pending', count: 5 },
				],
			},
		};
		const store = createMockStore(initialState);
		render(
			<Provider store={store}>
				<BrowserRouter>
					<DilSearch />
				</BrowserRouter>
			</Provider>,
		);
	});
});
