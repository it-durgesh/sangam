import { configureStore } from '@reduxjs/toolkit';
import reducer, {
	initialState,
	fetchBatchSummary,
	resetBatchSummary,
	setBatchIdWithDate,
} from './DilBatchSummary.slice';
import requestInstance from '../../utils/apiclient.services';
import { handleErrorResponse } from '../../utils/handleerror.services';
import ThunkApiStatus from '../../constants/ThunkApiStatus';

jest.mock('../../utils/apiclient.services');
jest.mock('../../utils/handleerror.services');

describe('DilBatchSummarySlice', () => {
	let store;

	beforeEach(() => {
		store = configureStore({ reducer: { batch: reducer } });
	});

	test('should return the initial state', () => {
		expect(store.getState().batch).toEqual(initialState);
	});

	describe('fetchBatchSummary', () => {
		it('should handle pending state', async () => {
			const action = fetchBatchSummary.pending('fetchBatchSummary', {});
			const state = reducer(initialState, action);
			expect(state.batchSummaryStatus).toBe(ThunkApiStatus.PENDING);
		});

		it('should handle fulfilled state with data', async () => {
			const mockData = [{ id: 1, name: 'Batch 1' }];
			requestInstance.get.mockResolvedValue({ data: mockData });

			await store.dispatch(fetchBatchSummary({ batchId: 1, businessDate: '2023-10-01' }));
			const state = store.getState().batch;

			expect(state.batchSummaryStatus).toBe(ThunkApiStatus.SUCCEEDED);
			expect(state.batchSummaryData).toEqual(mockData);
		});

		it('should handle rejected state with error', async () => {
			const mockError = new Error('Network Error');
			const mockHandledError = { message: 'Error occurred' };
			requestInstance.get.mockRejectedValue(mockError);
			handleErrorResponse.mockReturnValue(mockHandledError);

			await store.dispatch(fetchBatchSummary({ batchId: 1, businessDate: '2023-10-01' }));
			const state = store.getState().batch;

			expect(state.batchSummaryStatus).toBe(ThunkApiStatus.FAILED);
			expect(state.batchSummaryError).toEqual(mockHandledError);
		});
	});

	describe('Reducer Actions', () => {
		it('should reset to initial state with resetBatchSummary', () => {
			const action = resetBatchSummary();
			const state = reducer(initialState, action);
			expect(state).toEqual(initialState);
		});

		it('should set batchId and businessDate with setBatchIdWithDate', () => {
			const action = setBatchIdWithDate({ batchId: 123, businessDate: '2023-10-01' });
			const state = reducer(initialState, action);

			expect(state.batchId).toBe(123);
			expect(state.businessDate).toBe('2023-10-01');
		});
	});
});
