import DilSearchDetail from './DilSearchDetail';

export default DilSearchDetail;
