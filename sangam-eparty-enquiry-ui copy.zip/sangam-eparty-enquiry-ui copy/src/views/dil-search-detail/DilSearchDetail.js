import React from 'react';
import SearchGenerator from '../../components/dil-search/search-generator/SearchGenerator';

const DilSearchDetail = () => {
	return <SearchGenerator />;
};

export default DilSearchDetail;
