import { render } from '@testing-library/react';
import DilSearchDetail from './DilSearchDetail';

describe('DilSearchDetail component ', () => {
	test('calling dil search detail component', async () => {
		render(<DilSearchDetail />);
	});
});
