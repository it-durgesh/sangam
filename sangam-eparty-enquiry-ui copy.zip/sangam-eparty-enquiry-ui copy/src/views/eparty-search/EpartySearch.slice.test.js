import reducer, {
	resetEpartSearch,
	setLoading,
	setData,
	setError,
	setAccountLoading,
	setAccountData,
	setAccountError,
	initialState,
} from './EpartySearch.slice';
import ThunkApiStatus from '../../constants/ThunkApiStatus';

describe('EpartySearchSlice reducers', () => {
	it('should return the initial state when resetEpartSearch is called', () => {
		const state = reducer(
			{
				searchStatus: ThunkApiStatus.SUCCEEDED,
				searchData: { test: 'data' },
				searchError: null,
				accountStatus: ThunkApiStatus.SUCCEEDED,
				accountData: { test: 'account data' },
				accountError: null,
			},
			resetEpartSearch(),
		);
		expect(state).toEqual(initialState);
	});

	it('should set searchStatus to PENDING when setLoading is called', () => {
		const state = reducer(initialState, setLoading());
		expect(state.searchStatus).toBe(ThunkApiStatus.PENDING);
	});

	it('should set searchStatus to SUCCEEDED and update searchData when setData is called', () => {
		const state = reducer(initialState, setData('Test Party'));
		expect(state.searchStatus).toBe(ThunkApiStatus.SUCCEEDED);
	});

	it('should set searchStatus to FAILED and update searchError when setError is called', () => {
		const error = 'An error occurred';
		const state = reducer(initialState, setError('An error occurred'));
		expect(state.searchStatus).toBe(ThunkApiStatus.FAILED);
		expect(state.searchError).toBe(error);
	});

	it('should set accountStatus to PENDING when setAccountLoading is called', () => {
		const state = reducer(initialState, setAccountLoading());
		expect(state.accountStatus).toBe(ThunkApiStatus.PENDING);
	});

	it('should set accountStatus to SUCCEEDED and update accountData when setAccountData is called', () => {
		const state = reducer(initialState, setAccountData('Test Relationship'));
		expect(state.accountStatus).toBe(ThunkApiStatus.SUCCEEDED);
	});

	it('should set accountStatus to FAILED and update accountError when setAccountError is called', () => {
		const error = 'Account error occurred';
		const state = reducer(initialState, setAccountError('Account error occurred'));
		expect(state.accountStatus).toBe(ThunkApiStatus.FAILED);
		expect(state.accountError).toBe(error);
	});
});
