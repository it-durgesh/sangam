import { render } from '@testing-library/react';
import EpartySearch from './EpartySearch';

describe('EpartySearch component ', () => {
	test('calling e party search component', async () => {
		render(<EpartySearch />);
	});
});
