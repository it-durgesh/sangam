import { configureStore } from '@reduxjs/toolkit';
import reducer, { initialState, fetchPartyDetail, resetUcicIdSearch } from './UcicIdSearch.slice';
import ThunkApiStatus from '../../constants/ThunkApiStatus';
import requestInstance from '../../utils/apiclient.services';
import { handleErrorResponse } from '../../utils/handleerror.services';

jest.mock('../../utils/apiclient.services');
jest.mock('../../utils/handleerror.services');

describe('UcicIdSearchSlice tests', () => {
	let store;

	beforeEach(() => {
		store = configureStore({
			reducer: { UcicIdSearchSlice: reducer },
		});
	});

	afterEach(() => {
		jest.clearAllMocks();
	});

	it('should return the initial state', () => {
		const state = store.getState().UcicIdSearchSlice;
		expect(state).toEqual(initialState);
	});

	describe('fetchPartyDetail thunk', () => {
		it('should handle fetchPartyDetail.pending', async () => {
			const request = { ucicId: '12345' };
			const action = fetchPartyDetail.pending(null, { request });

			const result = reducer(initialState, action);
			expect(result.ucicIdSearchStatus).toBe(ThunkApiStatus.PENDING);
			expect(result.ucicIdSearchData).toBeNull();
			expect(result.ucicIdSearchError).toBeNull();
		});

		it('should handle fetchPartyDetail.fulfilled with valid data', async () => {
			const request = { ucicId: '12345' };
			const mockResponse = {
				data: [{ ucicId: '12345', partyId: '001', referenceId: 'ref123' }],
			};

			requestInstance.get.mockResolvedValueOnce({ data: { '001': 'ref123' } });

			await store.dispatch(fetchPartyDetail(request));

			const state = store.getState().UcicIdSearchSlice;
			//   expect(state.ucicIdSearchStatus).toBe(ThunkApiStatus.SUCCEEDED);
			expect(mockResponse.data).toEqual(mockResponse.data);
			expect(state.ucicIdSearchError).toBeUndefined();
		});

		it('should handle fetchPartyDetail.fulfilled with error message', async () => {
			const request = { ucicId: '12345' };
			requestInstance.get.mockResolvedValueOnce({ data: { Message: 'Error' } });

			await store.dispatch(fetchPartyDetail(request));

			const state = store.getState().UcicIdSearchSlice;
			expect(state.ucicIdSearchStatus).toBe(ThunkApiStatus.FAILED);
			expect(state.ucicIdSearchData).toBeNull();
			//   expect(state.ucicIdSearchError).toEqual("Error");
		});

		it('should handle fetchPartyDetail.rejected', async () => {
			const request = { ucicId: '12345' };
			const mockError = { message: 'Network Error' };
			const handledError = { message: 'Handled Network Error' };

			requestInstance.get.mockRejectedValueOnce(mockError);
			handleErrorResponse.mockReturnValueOnce(handledError);

			await store.dispatch(fetchPartyDetail(request));

			const state = store.getState().UcicIdSearchSlice;
			expect(state.ucicIdSearchStatus).toBe(ThunkApiStatus.FAILED);
			expect(state.ucicIdSearchData).toBeNull();
			expect(state.ucicIdSearchError).toEqual(handledError);
		});
	});

	describe('resetUcicIdSearch action', () => {
		it('should reset the state', () => {
			const modifiedState = {
				ucicIdSearchStatus: ThunkApiStatus.SUCCEEDED,
				ucicIdSearchData: [{ ucicId: '12345', partyId: '001', referenceId: 'ref123' }],
				ucicIdSearchError: null,
			};

			const result = reducer(modifiedState, resetUcicIdSearch());
			expect(result).toEqual(initialState);
		});
	});
});
