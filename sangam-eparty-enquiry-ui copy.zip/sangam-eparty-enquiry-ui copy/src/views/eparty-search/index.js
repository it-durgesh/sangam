import EpartySearch from './EpartySearch';

export default EpartySearch;
