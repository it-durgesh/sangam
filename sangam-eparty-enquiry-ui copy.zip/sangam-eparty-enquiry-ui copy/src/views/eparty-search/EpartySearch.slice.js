import { createSlice } from '@reduxjs/toolkit';
import ThunkApiStatus from '../../constants/ThunkApiStatus';

export const initialState = {
	searchStatus: ThunkApiStatus.IDLE,
	searchData: null,
	searchError: null,
	accountStatus: ThunkApiStatus.IDLE,
	accountData: null,
	accountError: null,
};

export const EpartySearchSlice = createSlice({
	name: 'EpartySearchSlice',
	initialState,
	reducers: {
		resetEpartSearch: () => initialState,
		setLoading: (state) => {
			state.searchStatus = ThunkApiStatus.PENDING;
		},
		setData: (state, action) => {
			state.searchStatus = ThunkApiStatus.SUCCEEDED;
			state.searchData = action.payload.findPartyPrimaryInformationView;
		},
		setError: (state, action) => {
			state.searchStatus = ThunkApiStatus.FAILED;
			state.searchError = action.payload;
		},
		setAccountLoading: (state) => {
			state.accountStatus = ThunkApiStatus.PENDING;
		},
		setAccountData: (state, action) => {
			state.accountStatus = ThunkApiStatus.SUCCEEDED;
			state.accountData = action.payload.findPartyAccountRelationshipView;
		},
		setAccountError: (state, action) => {
			state.accountStatus = ThunkApiStatus.FAILED;
			state.accountError = action.payload;
		},
	},
});
export const {
	resetEpartSearch,
	setData,
	setLoading,
	setError,
	setAccountData,
	setAccountLoading,
	setAccountError,
} = EpartySearchSlice.actions;
export default EpartySearchSlice.reducer;
