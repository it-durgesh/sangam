import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import ThunkApiStatus from '../../constants/ThunkApiStatus';
import requestInstance from '../../utils/apiclient.services';
import handleErrorResponse from '../../utils/handleerror.services';

export const initialState = {
	ucicIdSearchStatus: ThunkApiStatus.IDLE,
	ucicIdSearchData: null,
	ucicIdSearchError: null,
};

export const fetchPartyDetail = createAsyncThunk('fetchPartyDetail', async (request, thunkAPI) => {
	try {
		const response = await requestInstance.get(`/party-id/${request.ucicId}`).then((res) => {
			// TODO: remove below code once api changes are added, currently hardcode logic
			if (Object.keys(res.data).length === 1) {
				throw new Error(res.data.Message);
			}
			let formatData;
			if (Object.keys(res.data).length > 1) {
				formatData = [
					{
						ucicId: request.ucicId,
						partyId: res.data.partyId,
						referenceId: res.data.referenceId,
					},
				];
			}
			return {
				data: formatData,
			};
		});
		return response;
	} catch (error) {
		const err = handleErrorResponse(error);
		return thunkAPI.rejectWithValue(err);
	}
});

export const UcicIdSearchSlice = createSlice({
	name: 'UcicIdSearchSlice',
	initialState,
	reducers: {
		resetUcicIdSearch: () => initialState,
	},
	extraReducers: (builder) => {
		builder.addCase(fetchPartyDetail.pending, (state) => {
			state.ucicIdSearchStatus = ThunkApiStatus.PENDING;
		});
		builder.addCase(fetchPartyDetail.fulfilled, (state, action) => {
			state.ucicIdSearchStatus = ThunkApiStatus.SUCCEEDED;
			state.ucicIdSearchData = action.payload.data;
		});
		builder.addCase(fetchPartyDetail.rejected, (state, action) => {
			state.ucicIdSearchStatus = ThunkApiStatus.FAILED;
			state.ucicIdSearchError = action.payload;
		});
	},
});
export const { resetUcicIdSearch } = UcicIdSearchSlice.actions;
export default UcicIdSearchSlice.reducer;
