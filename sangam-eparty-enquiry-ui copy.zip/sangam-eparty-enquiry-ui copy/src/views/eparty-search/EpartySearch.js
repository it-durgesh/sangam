import React from 'react';
import SearchForm from '../../components/eparty-search/search-form/SearchForm';
import makeErrorBoundComponent from '../../components/error-boundary/make-error-bound-component';

const EpartySearch = () => {
	return <SearchForm />;
};
export default makeErrorBoundComponent(EpartySearch);
