import React from 'react';
import GeneralPageTitle from '../components/general-page-title';
import './PageNotFound.css';

const PageNotFound = () => {
	return (
		<div className="page-not-found">
			<GeneralPageTitle>Page does not exist</GeneralPageTitle>
			<hr className="page__separator" />
			<section className="page">
				<h2 className="page__title">This page does not exist.</h2>
				<p className=" page__contact">Contact your administrator for assistance.</p>
			</section>
		</div>
	);
};

PageNotFound.propTypes = {};

export default PageNotFound;
