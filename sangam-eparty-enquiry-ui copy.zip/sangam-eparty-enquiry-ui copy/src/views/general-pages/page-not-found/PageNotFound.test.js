import { render } from '@testing-library/react';
import PageNotFound from './PageNotFound';

describe('PageNotFound component ', () => {
	test('calling page not found component', async () => {
		render(<PageNotFound />);
	});
});
