import React from 'react';
import { oneOfType, string, node } from 'prop-types';
import './GeneralPageTitle.css';
import makeErrorBoundComponent from '../../../../components/error-boundary/make-error-bound-component';

const GeneralHeader = ({ children }) => {
	return <h1 className="general-page-title">{children}</h1>;
};

GeneralHeader.propTypes = {
	children: oneOfType([string, node]).isRequired,
};
export default makeErrorBoundComponent(GeneralHeader);
