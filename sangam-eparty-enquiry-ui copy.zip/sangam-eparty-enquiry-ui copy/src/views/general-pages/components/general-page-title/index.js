import GeneralPageTitle from './GeneralPageTitle';

export default GeneralPageTitle;
