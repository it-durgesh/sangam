import React from 'react';
import { render } from '@testing-library/react';
import GeneralHeader from './GeneralPageTitle';

jest.mock(
	'../../../../components/error-boundary/make-error-bound-component',
	() => (Component) => Component,
);

describe('GeneralHeader', () => {
	it('renders without crashing', () => {
		const { getByText } = render(<GeneralHeader>Test Title</GeneralHeader>);
		expect(getByText('Test Title')).toBeInTheDocument();
	});

	it('renders the correct text content', () => {
		const { getByText } = render(<GeneralHeader>Sample Header</GeneralHeader>);
		expect(getByText('Sample Header')).toBeInTheDocument();
	});

	it('applies the correct CSS class', () => {
		const { container } = render(<GeneralHeader>Styled Header</GeneralHeader>);
		expect(container.firstChild).toHaveClass('general-page-title');
	});

	it('throws an error when children prop is missing', () => {
		const consoleSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
		consoleSpy.mockRestore();
	});
});
