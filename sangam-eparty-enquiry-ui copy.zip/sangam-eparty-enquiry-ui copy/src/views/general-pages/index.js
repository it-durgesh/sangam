import PageNotFound from './page-not-found';

export default PageNotFound;
