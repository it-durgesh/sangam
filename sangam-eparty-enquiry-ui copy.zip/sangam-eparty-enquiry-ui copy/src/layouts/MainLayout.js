import * as React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation, useNavigate } from 'react-router-dom';
import { node } from 'prop-types';
import PersonSearchIcon from '@mui/icons-material/PersonSearch';
import QueryStatsIcon from '@mui/icons-material/QueryStats';
import { styled, useTheme } from '@mui/material/styles';
import {
	Box,
	Toolbar,
	List,
	Typography,
	Divider,
	ListItem,
	ListItemButton,
	ListItemIcon,
	ListItemText,
	Chip,
	Card,
	Popper,
} from '@mui/material';
import IconButton from '@mui/material/IconButton';
import MuiDrawer from '@mui/material/Drawer';
import MuiAppBar from '@mui/material/AppBar';
import MenuIcon from '@mui/icons-material/Menu';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import makeErrorBoundComponent from '../components/error-boundary/make-error-bound-component';
import HeaderTitle from '../constants/HeaderTitle';
import Path from '../constants/Routes';
import Logo from '../assets/HdfcLogo.png';
import { COMMON } from '../constants/Common';
import { resetDilBatchStatus } from '../views/dil-search/DilBatchStatus.slice';
import { resetBatchSummary } from '../views/dil-search/DilBatchSummary.slice';
import { resetEpartSearch } from '../views/eparty-search/EpartySearch.slice';
import { resetUcicIdSearch } from '../views/eparty-search/UcicIdSearch.slice';
import { dateToStringForParseDate } from '../utils/datetime.service';
import styles from './MainLayout.module.css';

const drawerWidth = 240;

const openedMixin = (theme) => ({
	width: drawerWidth,
	transition: theme.transitions.create('width', {
		easing: theme.transitions.easing.sharp,
		duration: theme.transitions.duration.enteringScreen,
	}),
	overflowX: 'hidden',
});

const closedMixin = (theme) => ({
	transition: theme.transitions.create('width', {
		easing: theme.transitions.easing.sharp,
		duration: theme.transitions.duration.leavingScreen,
	}),
	overflowX: 'hidden',
	width: `calc(${theme.spacing(7)} + 1px)`,
	[theme.breakpoints.up('sm')]: {
		width: `calc(${theme.spacing(8)} + 1px)`,
	},
});

const DrawerHeader = styled('div')(({ theme }) => ({
	display: 'flex',
	alignItems: 'center',
	justifyContent: 'flex-end',
	padding: theme.spacing(0, 1),
	// necessary for content to be below app bar
	...theme.mixins.toolbar,
}));

const AppBar = styled(MuiAppBar, {
	shouldForwardProp: (prop) => prop !== 'open',
})(({ theme }) => ({
	zIndex: theme.zIndex.drawer + 1,
	transition: theme.transitions.create(['width', 'margin'], {
		easing: theme.transitions.easing.sharp,
		duration: theme.transitions.duration.leavingScreen,
	}),
	variants: [
		{
			props: ({ open }) => open,
			style: {
				marginLeft: drawerWidth,
				width: `calc(100% - ${drawerWidth}px)`,
				transition: theme.transitions.create(['width', 'margin'], {
					easing: theme.transitions.easing.sharp,
					duration: theme.transitions.duration.enteringScreen,
				}),
			},
		},
	],
}));

const Drawer = styled(MuiDrawer, {
	shouldForwardProp: (prop) => prop !== 'open',
})(({ theme }) => ({
	width: drawerWidth,
	flexShrink: 0,
	whiteSpace: 'nowrap',
	boxSizing: 'border-box',
	variants: [
		{
			props: ({ open }) => open,
			style: {
				...openedMixin(theme),
				'& .MuiDrawer-paper': openedMixin(theme),
			},
		},
		{
			props: ({ open }) => !open,
			style: {
				...closedMixin(theme),
				'& .MuiDrawer-paper': closedMixin(theme),
			},
		},
	],
}));
const MainLayout = (props) => {
	const navigate = useNavigate();
	const dispatch = useDispatch();
	const location = useLocation();
	const { children, title } = props;
	const theme = useTheme();
	const [open, setOpen] = React.useState(false);

	const [anchorEl, setAnchorEl] = React.useState(null);

	const handleClick = (event) => {
		setAnchorEl(anchorEl ? null : event.currentTarget);
	};

	const openPopover = Boolean(anchorEl);
	const id = openPopover ? 'party-id-popper' : undefined;

	const handleDrawerOpen = () => {
		setOpen(true);
	};

	const handleDrawerClose = () => {
		setOpen(false);
	};

	const resetAllState = () => {
		dispatch(resetDilBatchStatus());
		dispatch(resetUcicIdSearch());
		dispatch(resetBatchSummary());
		dispatch(resetEpartSearch());
	};

	const handleNavigate = (path) => {
		navigate(path);
		resetAllState();
	};

	const { searchData } = useSelector((state) => state.EpartySearchSlice);
	const isDetailPage = location.pathname === '/eparty-detail';

	const { batchId } = useSelector((state) => state.DilBatchSummarySlice);

	const isDilPage = location.pathname.includes('/dil') && batchId;

	return (
		<Box sx={{ display: 'flex' }}>
			<AppBar position="fixed" open={open}>
				<Toolbar>
					<IconButton
						color="inherit"
						aria-label="open drawer"
						onClick={handleDrawerOpen}
						edge="start"
						sx={[
							{
								marginRight: 5,
							},
							open && { display: 'none' },
						]}
					>
						<MenuIcon />
					</IconButton>
					<Typography variant="h6" noWrap component="div">
						{title}
					</Typography>
					{isDetailPage && (
						<>
							<Typography
								variant="h6"
								noWrap
								component="div"
								sx={{ marginLeft: 'auto' }}
							>
								Party Id:{' '}
								<Chip
									aria-owns={openPopover ? 'mouse-over-popover' : undefined}
									aria-haspopup="true"
									aria-describedby={id}
									type="button"
									onClick={handleClick}
									label={searchData?.id || ''}
									sx={{
										background: `${theme.palette.background.paper}!important`,
									}}
									variant="outlined"
								/>
							</Typography>
							<Popper
								id={id}
								open={openPopover}
								anchorEl={anchorEl}
								placement="bottom"
								disablePortal
							>
								<Card variant="outlined" className={styles.headerDropdown}>
									<Typography className={styles.headerDropdownContent}>
										Creator: <strong>{searchData?.createdBy || ''}</strong>
									</Typography>
									<Typography className={styles.headerDropdownContent}>
										Date:{' '}
										<strong>
											{dateToStringForParseDate(searchData?.createdOn) || ''}
										</strong>
									</Typography>
									<Typography className={styles.headerDropdownContent}>
										Status:{' '}
										<strong
											className={
												searchData?.status === COMMON.ACTIVE &&
												styles.textActive
											}
										>
											{searchData?.status || ''}
										</strong>
									</Typography>
									<Typography className={styles.headerDropdownContent}>
										Version: <strong>{searchData?.version || ''}</strong>
									</Typography>
								</Card>
							</Popper>
						</>
					)}
					{isDilPage && (
						<Typography variant="h6" noWrap component="div" sx={{ marginLeft: 'auto' }}>
							Batch Id:{' '}
							<Chip
								type="button"
								label={batchId}
								sx={{
									background: `${theme.palette.background.paper}!important`,
								}}
								variant="outlined"
							/>
						</Typography>
					)}
				</Toolbar>
			</AppBar>
			<Drawer variant="permanent" open={open}>
				<DrawerHeader sx={{ justifyContent: 'space-around' }}>
					<IconButton color="primary">
						<img src={Logo} alt="logo" />
					</IconButton>
					<IconButton onClick={handleDrawerClose}>
						{theme.direction === 'rtl' ? <ChevronRightIcon /> : <ChevronLeftIcon />}
					</IconButton>
				</DrawerHeader>
				<Divider />
				<List>
					<ListItem
						disablePadding
						sx={{ display: 'block' }}
						onClick={() => handleNavigate(Path.ROOT)}
					>
						<ListItemButton
							sx={[
								{
									minHeight: 48,
									px: 2.5,
								},
								open
									? {
											justifyContent: 'initial',
										}
									: {
											justifyContent: 'center',
										},
							]}
						>
							<ListItemIcon
								sx={[
									{
										minWidth: 0,
										justifyContent: 'center',
									},
									open
										? {
												mr: 3,
											}
										: {
												mr: 'auto',
											},
								]}
							>
								<PersonSearchIcon />
							</ListItemIcon>
							<ListItemText
								primary={HeaderTitle.EPARTY_SERACH}
								sx={[
									open
										? {
												opacity: 1,
											}
										: {
												opacity: 0,
											},
								]}
							/>
						</ListItemButton>
					</ListItem>
				</List>
				<Divider />
				<List>
					{[HeaderTitle.DIL].map((text) => (
						<ListItem
							key={text}
							disablePadding
							sx={{ display: 'block' }}
							onClick={() => handleNavigate(Path.DIL)}
						>
							<ListItemButton
								sx={[
									{
										minHeight: 48,
										px: 2.5,
									},
									open
										? {
												justifyContent: 'initial',
											}
										: {
												justifyContent: 'center',
											},
								]}
							>
								<ListItemIcon
									sx={[
										{
											minWidth: 0,
											justifyContent: 'center',
										},
										open
											? {
													mr: 3,
												}
											: {
													mr: 'auto',
												},
									]}
								>
									<QueryStatsIcon />
								</ListItemIcon>
								<ListItemText
									primary={text}
									sx={[
										open
											? {
													opacity: 1,
												}
											: {
													opacity: 0,
												},
									]}
								/>
							</ListItemButton>
						</ListItem>
					))}
				</List>
			</Drawer>
			<Box component="main" sx={{ flexGrow: 1, p: 1 }}>
				<DrawerHeader />
				{children}
			</Box>
		</Box>
	);
};
MainLayout.propTypes = {
	children: node,
};

export default makeErrorBoundComponent(MainLayout);
