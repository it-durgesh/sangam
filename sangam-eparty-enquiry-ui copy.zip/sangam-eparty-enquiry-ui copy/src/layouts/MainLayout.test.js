import { render, screen, fireEvent } from '@testing-library/react';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import MainLayout from './MainLayout';

// Mock store
const mockStore = configureStore([]);

// Mock slices
const initialState = {
	EpartySearchSlice: {
		searchData: {
			id: '123',
			createdBy: 'John Doe',
			createdOn: '2023-01-01',
			status: 'Active',
			version: '1.0',
		},
	},
	DilBatchSummarySlice: { batchId: '456' },
};

describe('MainLayout component', () => {
	let store;
	let dispatchMock;

	beforeEach(() => {
		store = mockStore(initialState);
		dispatchMock = jest.fn();
	});

	const renderComponent = (props = {}) => {
		return render(
			<Provider store={store}>
				<BrowserRouter>
					<MainLayout {...props} />
				</BrowserRouter>
			</Provider>,
		);
	};

	test('renders component with title', () => {
		renderComponent({ title: 'Test Title' });
		expect(screen.getByText('Test Title')).toBeInTheDocument();
	});

	test('opens and closes the drawer', () => {
		renderComponent();

		// Open drawer
		const openButton = screen.getByLabelText('open drawer');
		fireEvent.click(openButton);
		expect(openButton).toBeInTheDocument();
	});

	test('navigates to eparty search and resets state', () => {
		renderComponent();

		const epartyListItem = screen.getByText('Eparty Search');
		fireEvent.click(epartyListItem);
	});

	test('displays batch ID in DIL page', () => {
		renderComponent();
	});

	test('displays party ID and details in Eparty Detail page', () => {
		// Mock location for Eparty Detail page
		jest;

		renderComponent();
	});
});
