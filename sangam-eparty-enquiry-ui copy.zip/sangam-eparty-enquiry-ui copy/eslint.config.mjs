/* eslint-disable import/no-extraneous-dependencies */
import { FlatCompat } from '@eslint/eslintrc';
import babelParser from '@babel/eslint-parser';
import eslintPluginReact from 'eslint-plugin-react';
import eslintCommentsPlugin from 'eslint-plugin-eslint-comments';
import gitignore from 'eslint-config-flat-gitignore';

// Create a compatibility layer for `.eslintrc` rules
const compat = new FlatCompat();

export default [
	gitignore(),
	...compat.extends('airbnb'),
	...compat.extends('plugin:prettier/recommended'),
	{
		files: ['**/*.js', '**/*.jsx'],
		languageOptions: {
			parser: babelParser,
			parserOptions: {
				ecmaVersion: 2020,
				sourceType: 'module',
				ecmaFeatures: {
					jsx: true,
				},
			},
		},
		plugins: {
			react: eslintPluginReact,
			'eslint-comments': eslintCommentsPlugin,
		},
		rules: {
			'no-tabs': 'off',
			'no-undef': 'off',
			'no-console': 'error',
			'max-depth': ['warn', 3],
			'one-var': ['error', 'never'],
			'react/jsx-filename-extension': ['warn', { extensions: ['.js', '.jsx'] }],
			'no-unused-vars': [
				'error',
				{ argsIgnorePattern: '^_', caughtErrors: 'all', varsIgnorePattern: '^_' },
			],
			'react/jsx-props-no-spreading': 'off',
			'react/function-component-definition': ['error', { namedComponents: 'arrow-function' }],
			'no-underscore-dangle': 'off',
			'no-param-reassign': 0,
			'react/prop-types': 'off',
			'react/destructuring-assignment': 'off',
			'no-use-before-define': ['error', { variables: false }],
			'consistent-return': 'off',
			'react/jsx-no-useless-fragment': 'off',
			'no-nested-ternary': 'off',
			'no-else-return': 'error',
			// Part: import rules
			'import/prefer-default-export': 'error',
			'import/no-named-as-default': 0,
			'import/no-named-as-default-member': 0,
			'import/consistent-type-specifier-style': 'warn',
			'import/export': 'error',
			'import/first': 'warn',
			'import/newline-after-import': 'warn',
			'import/no-absolute-path': 'error',
			'import/no-duplicates': 'error',
			'import/no-dynamic-require': 'error',
			'import/no-empty-named-blocks': 'error',
			'import/no-extraneous-dependencies': 'error',
			'import/no-mutable-exports': 'error',
			'import/no-self-import': 'error',
			'import/extensions': ['error', 'ignorePackages', { js: 'never', jsx: 'never' }],
			// Part: eslint-comments rules
			'eslint-comments/disable-enable-pair': ['error', { allowWholeFile: true }],
			'eslint-comments/no-aggregating-enable': 'error',
			'eslint-comments/no-duplicate-disable': 'error',
			'eslint-comments/no-unlimited-disable': 'error',
			'eslint-comments/no-unused-disable': 'error',
			'eslint-comments/no-unused-enable': 'error',
			'eslint-comments/no-use': [
				'error',
				{
					allow: [
						'eslint-disable',
						'eslint-disable-line',
						'eslint-disable-next-line',
						'eslint-enable',
						'global',
					],
				},
			],
			'react/no-array-index-key': 'off',
			'react/react-in-jsx-scope': 'off',
			'react/jsx-one-expression-per-line': 'off',
			'global-require': 'off',
			'react/require-default-props': [
				0,
				{
					forbidDefaultForRequired: 0,
					classes: 'defaultProps' || 'ignore',
					functions: 'defaultProps' || 'defaultArguments' || 'ignore',
					ignoreFunctionalComponents: 0,
				},
			],
		},
	},
];
